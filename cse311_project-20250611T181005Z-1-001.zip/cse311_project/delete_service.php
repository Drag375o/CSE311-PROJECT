<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_management_system";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$successMsg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['service_id'])) {
    $service_id = $_POST['service_id'];

    // Start transaction
    $conn->begin_transaction();

    try {
        // Delete from Service table
        $conn->query("DELETE FROM Service WHERE service_id = $service_id");

        $conn->commit();
        $successMsg = "Service and all related information deleted successfully.";
    } catch (Exception $e) {
        $conn->rollback();
        $successMsg = "Error deleting service: " . $e->getMessage();
    }
}

// Fetch all services for the dropdown
$result = $conn->query("SELECT service_id, name FROM Service");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Service</title>
    <link rel="stylesheet" type="text/css" href="delete_service_style.css">
</head>
<body>

<div class="sidebar">
    <h1>HDMS</h1>
    <a href="admin_home_page.php">Home</a>
    <a href="delete_service.php">Delete</a>
    <a href="HOME_PAGE.php">Logout</a>
</div>

<div class="main-content">
    <h1>Delete Service</h1>
    <form method="post" action="delete_service.php">
        <label for="service_id">Select Service:</label>
        <select name="service_id" required>
            <option value="" disabled selected>Select a service</option>
            <?php
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['service_id'] . "'>ID: " . $row['service_id'] . " | " . $row['name'] . "</option>";
            }
            ?>
        </select>
        <br><br>
        <input type="submit" value="Delete Service">
    </form>
    <div class="success-msg"><?php echo $successMsg; ?></div>
</div>

<div class="footer">
    <p>&copy; 2025 Hospital Management System</p>
</div>

</body>
</html>
