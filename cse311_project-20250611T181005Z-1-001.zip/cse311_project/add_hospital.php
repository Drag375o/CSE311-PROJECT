<?php
// Connecting to the MySQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_management_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handling the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $hospital_name = $_POST['hospital_name'];
    $street_no = $_POST['street_no'];
    $street_name = $_POST['street_name'];
    $city = $_POST['city'];
    $mobile = $_POST['mobile'];

    // Validate mobile number (must be 11 digits, all numeric)
    if (!preg_match("/^[0-9]{11}$/", $mobile)) {
        $message = "Mobile number must be exactly 11 digits and contain only numbers.";
    }
    // Validate hospital_name (must not contain digits)
    elseif (preg_match("/[0-9]/", $hospital_name)) {
        $message = "Hospital name must not contain any digits.";
    }
    // Validate street_no (must be numeric)
    elseif (!preg_match("/^[0-9]+$/", $street_no)) {
        $message = "Street number must contain only numbers.";
    }
    // Validate street_name (must not contain digits)
    elseif (preg_match("/[0-9]/", $street_name)) {
        $message = "Street name must not contain any digits.";
    }
    // Validate city (must not contain digits)
    elseif (preg_match("/[0-9]/", $city)) {
        $message = "City name must not contain any digits.";
    } else {
        // Fetch the highest hospital_id and increment it
        $sql = "SELECT MAX(hospital_id) AS max_id FROM Hospital";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $new_hospital_id = $row['max_id'] + 1;  // Increment the max_id by 1

        // SQL query to insert data into the Hospital table
        $sql = "INSERT INTO Hospital (hospital_id, hospital_name, street_no, street_name, city)
                VALUES ('$new_hospital_id', '$hospital_name', '$street_no', '$street_name', '$city')";
        
        if ($conn->query($sql) === TRUE) {
            // Insert mobile number into the Hospital_Mobile table
            $sql_mobile = "INSERT INTO Hospital_Mobile (hospital_id, mobile)
                           VALUES ('$new_hospital_id', '$mobile')";
            
            if ($conn->query($sql_mobile) === TRUE) {
                $message = "Hospital added successfully!";
            } else {
                $message = "Error adding mobile: " . $conn->error;
            }
        } else {
            $message = "Error adding hospital: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Hospital</title>
    <link rel="stylesheet" href="add_hospital_style.css"> <!-- Link to external CSS -->
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <h2 class="sidebar-title">Admin Operations</h2>
        <ul class="nav-list">
            <li><a href="admin_home_page.php">Home</a></li>
            <li><a href="add_hospital.php">Add Hospital</a></li>
            <li><a href="edit_hospital.php">Edit Hospital</a></li>
            <li><a href="delete_hospital.php">Delete Hospital</a></li>
            <li><a href="view_hospital.php">View Hospital</a></li>
            <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">Add Hospital</h1>

        <!-- Message after form submission -->
        <?php if (isset($message)) { echo "<p class='message'>$message</p>"; } ?>

        <!-- Hospital Information Form -->
        <div class="form-container">
            <form method="POST" action="">
                <label for="hospital_name">Hospital Name:</label>
                <input type="text" id="hospital_name" name="hospital_name" required>

                <label for="street_no">Street No:</label>
                <input type="text" id="street_no" name="street_no" required>

                <label for="street_name">Street Name:</label>
                <input type="text" id="street_name" name="street_name" required>

                <label for="city">City:</label>
                <input type="text" id="city" name="city" required>

                <label for="mobile">Mobile Number:</label>
                <input type="text" id="mobile" name="mobile" maxlength="11" pattern="\d{11}" required>

                <button type="submit">Add Hospital</button>
            </form>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        The project is made by group 18
    </footer>
</body>
</html>
