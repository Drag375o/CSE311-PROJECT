<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hospital_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch hospital data with their mobile numbers
$sql = "SELECT h.hospital_id, h.hospital_name, h.street_no, h.street_name, h.city, m.mobile
        FROM Hospital h
        LEFT JOIN Hospital_Mobile m ON h.hospital_id = m.hospital_id
        ORDER BY h.hospital_id";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Hospitals</title>
    <link rel="stylesheet" type="text/css" href="view_hospital_style.css">
</head>
<body>
<div class="wrapper">
    <div class="sidebar">
        <h2>Navigation</h2>
        <a href="admin_home_page.php">Home</a>
        <a href="view_hospital.php">View</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Hospital Information</h1>
        <div class="hospital-container">
            <?php
            if ($result->num_rows > 0) {
                echo "<table>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Street Number</th>
                            <th>Street Name</th>
                            <th>City</th>
                            <th>Mobile</th>
                        </tr>";
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $row['hospital_id'] . "</td>
                            <td>" . $row['hospital_name'] . "</td>
                            <td>" . $row['street_no'] . "</td>
                            <td>" . $row['street_name'] . "</td>
                            <td>" . $row['city'] . "</td>
                            <td>" . $row['mobile'] . "</td>
                          </tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No hospital data found.</p>";
            }
            ?>
        </div>
    </div>
</div>

<div class="footer">
    &copy; 2025 Hospital Management System
</div>
</body>
</html>
