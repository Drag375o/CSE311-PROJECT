<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Service Home</title>
    <link rel="stylesheet" href="service_home_page_style.css"> 
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <h2 class="sidebar-title">Service Operations</h2>
        <ul class="nav-list">
            <li><a href="admin_home_page.php">Home</a></li>
            <li><a href="add_service.php">Add Service</a></li>
            <li><a href="edit_service.php">Edit Service</a></li>
            <li><a href="delete_service.php">Delete Service</a></li>
            <li><a href="view_service.php">View Service</a></li>
            <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">Service Management</h1>
        <p class="page-description">
            Welcome to the Service Management page. Here you can add a new service, edit existing service details, or delete a service. Use the options given to perform the actions.
        </p>

        <!-- Service Operations Cards -->
        <div class="card-container">
            <div class="card">
                <h3>Add Service</h3>
                <p>Click here to add a new service to the system.</p>
                <a href="add_service.php" class="card-button">Add</a>
            </div>
            <div class="card">
                <h3>Edit Service</h3>
                <p>Click here to edit existing service information.</p>
                <a href="edit_service.php" class="card-button">Edit</a>
            </div>
            <div class="card">
                <h3>Delete Service</h3>
                <p>Click here to delete an existing service from the system.</p>
                <a href="delete_service.php" class="card-button">Delete</a>
            </div>
            <div class="card">
                <h3>View Service</h3>
                <p>Click here to view existing services from the system.</p>
                <a href="view_service.php" class="card-button">view</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        The project is made by group 18
    </footer>
</body>
</html>
