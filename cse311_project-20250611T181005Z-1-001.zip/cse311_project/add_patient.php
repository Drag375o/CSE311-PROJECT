<?php
// Connect to MySQL
$conn = new mysqli("localhost", "root", "", "hospital_management_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $patient_id = $_POST['patient_id'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $street_no = $_POST['street_no'];
    $street_name = $_POST['street_name'];
    $city = $_POST['city'];
    $nid = $_POST['nid'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $mobiles = array_filter([$_POST['mobile1'], $_POST['mobile2'], $_POST['mobile3']]);
    $medical_history = array_filter(explode(",", $_POST['medical_history']));
    $is_emergency = isset($_POST['emergency']);
    $is_regular = isset($_POST['regular']);
    $stable_status = $_POST['stable_status'] ?? null;
    $update_info = $_POST['update_info'] ?? null;

    // Calculate age
    $today = new DateTime();
    $birth_date = new DateTime($dob);
    $age = $today->diff($birth_date)->y;

    if ($age > 120 || $age < 0) {
        echo "<script>alert('Invalid age!');</script>";
    } elseif (!$is_emergency && !$is_regular) {
        echo "<script>alert('Select emergency or regular classification!');</script>";
    } elseif ($is_emergency && $is_regular) {
        echo "<script>alert('Only one classification is allowed!');</script>";
    } else {
        $conn->begin_transaction();

        try {
            // Insert into Patient
            $stmt = $conn->prepare("INSERT INTO Patient VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issssssiss", $patient_id, $first_name, $middle_name, $last_name, $street_no, $street_name, $city, $nid, $dob, $gender);
            $stmt->execute();

            // Insert into Pat_Mobile
            $stmt = $conn->prepare("INSERT INTO Pat_Mobile VALUES (?, ?)");
            foreach ($mobiles as $mobile) {
                $stmt->bind_param("is", $patient_id, $mobile);
                $stmt->execute();
            }

            // Insert into Pat_Medical_History
            $stmt = $conn->prepare("INSERT INTO Pat_Medical_History VALUES (?, ?)");
            $stmt->bind_param("is", $patient_id, $trimmed_history);
            foreach ($medical_history as $history) {
                $trimmed_history = trim($history);
                $stmt->execute();
            }

            // Insert into emergency or regular table
            if ($is_emergency) {
                $stmt = $conn->prepare("INSERT INTO emergency_patient VALUES (?, ?)");
                $stmt->bind_param("is", $patient_id, $stable_status);
                $stmt->execute();
            } elseif ($is_regular) {
                $stmt = $conn->prepare("INSERT INTO regular_patient VALUES (?, ?)");
                $stmt->bind_param("is", $patient_id, $update_info);
                $stmt->execute();
            }

            $conn->commit();
            echo "<script>alert('Patient successfully added!');</script>";
        } catch (Exception $e) {
            $conn->rollback();
            echo "<script>alert('Error: " . $e->getMessage() . "');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Patient</title>
    <link rel="stylesheet" type="text/css" href="add_patient_style.css">
</head>
<body>
    <div class="sidebar">
        <a href="admin_home_page.php">Home</a>
        <a href="add_patient.php">Add</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h2>Add New Patient</h2>
        <form method="post" action="">
            <label>Patient ID:</label>
            <input type="number" name="patient_id" required min="1"><br>

            <label>First Name:</label>
            <input type="text" name="first_name" pattern="[A-Za-z]+" required><br>

            <label>Middle Name:</label>
            <input type="text" name="middle_name" pattern="[A-Za-z]*"><br>

            <label>Last Name:</label>
            <input type="text" name="last_name" pattern="[A-Za-z]+" required><br>

            <label>NID:</label>
            <input type="number" name="nid" required><br>

            <label>Date of Birth:</label>
            <input type="date" name="dob" required><br>

            <label>Gender:</label>
            <select name="gender" required>
                <option value="">--Select--</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select><br>

            <label>Street No:</label>
            <input type="text" name="street_no" pattern="[0-9]{1,10}" required><br>

            <label>Street Name:</label>
            <input type="text" name="street_name" pattern="[A-Za-z ]+" required><br>

            <label>City:</label>
            <input type="text" name="city" pattern="[A-Za-z ]+" required><br>

            <label>Mobile 1:</label>
            <input type="text" name="mobile1" pattern="[0-9]{11}" required><br>
            <label>Mobile 2:</label>
            <input type="text" name="mobile2" pattern="[0-9]{11}"><br>
            <label>Mobile 3:</label>
            <input type="text" name="mobile3" pattern="[0-9]{11}"><br>

            <label>Medical History (comma-separated):</label>
            <input type="text" name="medical_history"><br>

            <label>Classification:</label><br>
            <input type="checkbox" name="emergency" id="emergency">
            <label for="emergency">Emergency Patient</label>
            <select name="stable_status">
                <option value="">--Select--</option>
                <option value="1">Stable</option>
                <option value="0">Unstable</option>
            </select><br>

            <input type="checkbox" name="regular" id="regular">
            <label for="regular">Regular Patient</label>
            <select name="update_info">
                <option value="">--Select--</option>
                <option value="Sick">Sick</option>
                <option value="Well">Well</option>
            </select><br>

            <div class="center-btn">
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>

    <div class="footer">
        <p>© 2025 Hospital Management System</p>
    </div>

    <script>
        const emergencyCheckbox = document.getElementById("emergency");
        const regularCheckbox = document.getElementById("regular");
        const stableSelect = document.querySelector("select[name='stable_status']");
        const updateInfoSelect = document.querySelector("select[name='update_info']");

        function updateFormState() {
            if (emergencyCheckbox.checked) {
                regularCheckbox.disabled = true;
                stableSelect.disabled = false;
                updateInfoSelect.disabled = true;
                updateInfoSelect.selectedIndex = 0;
            } else {
                regularCheckbox.disabled = false;
                stableSelect.disabled = true;
                stableSelect.selectedIndex = 0;
            }

            if (regularCheckbox.checked) {
                emergencyCheckbox.disabled = true;
                updateInfoSelect.disabled = false;
                stableSelect.disabled = true;
                stableSelect.selectedIndex = 0;
            } else {
                emergencyCheckbox.disabled = false;
                if (!emergencyCheckbox.checked) stableSelect.disabled = true;
