<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "hospital_management_system";
$conn = new mysqli($host, $user, $password, $db);

// Fetch all hospitals for the dropdown
$hospital_query = "SELECT hospital_id, hospital_name FROM Hospital";
$hospital_result = $conn->query($hospital_query);

// Initialize empty values
$hospital_id = $hospital_name = $street_no = $street_name = $city = "";
$mobiles = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['fetch'])) {
    $hospital_id = $_POST['hospital_id'];
    $sql = "SELECT * FROM Hospital WHERE hospital_id=$hospital_id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    $hospital_name = $row['hospital_name'];
    $street_no = $row['street_no'];
    $street_name = $row['street_name'];
    $city = $row['city'];

    $mobile_sql = "SELECT mobile FROM Hospital_Mobile WHERE hospital_id=$hospital_id";
    $mobile_result = $conn->query($mobile_sql);
    while ($m = $mobile_result->fetch_assoc()) {
        $mobiles[] = $m['mobile'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $hospital_id = $_POST['hospital_id'];
    $hospital_name = $_POST['hospital_name'];
    $street_no = $_POST['street_no'];
    $street_name = $_POST['street_name'];
    $city = $_POST['city'];
    $mobile_numbers = array_filter($_POST['mobile']);

    // Update Hospital
    $update_sql = "UPDATE Hospital SET 
        hospital_name='$hospital_name', 
        street_no='$street_no', 
        street_name='$street_name', 
        city='$city' 
        WHERE hospital_id=$hospital_id";
    $conn->query($update_sql);

    // Update Hospital_Mobile
    $conn->query("DELETE FROM Hospital_Mobile WHERE hospital_id=$hospital_id");
    foreach ($mobile_numbers as $mob) {
        $conn->query("INSERT INTO Hospital_Mobile (hospital_id, mobile) VALUES ($hospital_id, '$mob')");
    }

    echo "<script>alert('Hospital information updated successfully.');</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Hospital</title>
    <link rel="stylesheet" type="text/css" href="edit_hospital_style.css">
</head>
<body>
    <div class="sidebar">
        <h2>Menu</h2>
        <a href="admin_home_page.php">Home</a>
        <a href="edit_hospital.php">Edit</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Edit Hospital Information</h1>

        <!-- Select Hospital to Edit -->
        <form method="POST">
            <label for="hospital_id">Select Hospital:</label>
            <select name="hospital_id" required>
                <option value="">--Select--</option>
                <?php while ($row = $hospital_result->fetch_assoc()) { ?>
                    <option value="<?= $row['hospital_id'] ?>" <?= ($hospital_id == $row['hospital_id']) ? 'selected' : '' ?>>
                        <?= $row['hospital_id'] ?> - <?= $row['hospital_name'] ?>
                    </option>
                <?php } ?>
            </select>
            <button type="submit" name="fetch">Fetch</button>
        </form>

        <?php if (!empty($hospital_name)) { ?>
        <form method="POST" class="edit-form">
            <input type="hidden" name="hospital_id" value="<?= $hospital_id ?>">

            <label>Hospital Name:</label>
            <input type="text" name="hospital_name" value="<?= $hospital_name ?>" required pattern="[A-Za-z0-9\s]+" title="Letters and numbers only.">

            <label>Street No:</label>
            <input type="text" name="street_no" value="<?= $street_no ?>" required pattern="[0-9]+" title="Numbers only.">

            <label>Street Name:</label>
            <input type="text" name="street_name" value="<?= $street_name ?>" required pattern="[A-Za-z\s]+" title="Letters only.">

            <label>City:</label>
            <input type="text" name="city" value="<?= $city ?>" required pattern="[A-Za-z\s]+" title="Letters only.">

            <label>Mobile Numbers:</label>
            <?php
            for ($i = 0; $i < 3; $i++) {
                $mob_val = isset($mobiles[$i]) ? $mobiles[$i] : '';
                echo "<input type='text' name='mobile[]' value='$mob_val' pattern='[0-9]+' title='Only digits allowed.'>";
            }
            ?>
            <button type="submit" name="update">Update Hospital</button>
        </form>
        <?php } ?>
    </div>

    <div class="footer">© Hospital Management System</div>
</body>
</html>
