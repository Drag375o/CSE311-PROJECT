<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "hospital_management_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch patients for dropdown
$patients = [];
$result = $conn->query("SELECT patient_id, CONCAT(first_name, ' ', middle_name, ' ', last_name) AS full_name FROM Patient");
while ($row = $result->fetch_assoc()) {
    $patients[] = $row;
}

// Handle deletion
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['patient_id'])) {
    $pid = $_POST['patient_id'];

    // Order of deletion to maintain referential integrity
    $conn->query("DELETE FROM lab_patient_hospital WHERE patient_id = $pid");
    $conn->query("DELETE FROM Appointment WHERE patient_id = $pid");
    $conn->query("DELETE FROM Report WHERE patient_id = $pid");
    $conn->query("DELETE FROM emergency_patient WHERE patient_id = $pid");
    $conn->query("DELETE FROM regular_patient WHERE patient_id = $pid");
    $conn->query("DELETE FROM Pat_Medical_History WHERE patient_id = $pid");
    $conn->query("DELETE FROM Pat_Mobile WHERE patient_id = $pid");
    $conn->query("DELETE FROM Patient WHERE patient_id = $pid");

    $message = "Patient and all related data successfully deleted.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Delete Patient</title>
    <link rel="stylesheet" href="delete_patient_style.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="sidebar-title">HDMS</div>
    <ul class="nav-list">
        <li><a href="admin_home_page.php">Home</a></li>
        <li><a href="delete_patient.php">Delete</a></li>
        <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
    </ul>
</div>

<!-- Main content -->
<div class="main-content">
    <h1 class="page-title">Delete Patient</h1>

    <?php if ($message): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <div class="form-container">
        <form method="POST" action="">
            <label for="patient_id">Select Patient to Delete:</label>
            <select name="patient_id" required>
                <option value="" disabled selected>-- Select a Patient --</option>
                <?php foreach ($patients as $patient): ?>
                    <option value="<?php echo $patient['patient_id']; ?>">
                        <?php echo $patient['patient_id'] . " - " . $patient['full_name']; ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="submit" value="Delete Patient">
        </form>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    The project is made by group 18
</div>

</body>
</html>
