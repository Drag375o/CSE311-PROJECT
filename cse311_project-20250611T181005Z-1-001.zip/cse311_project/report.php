<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hospital_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get distinct patient IDs from lab_patient_hospital table
$patients_result = $conn->query("SELECT DISTINCT patient_id FROM lab_patient_hospital");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $report_id = $_POST['report_id'];
    $date = date('Y-m-d');
    $diagnosis = $_POST['diagnosis'];
    $patient_id = $_POST['patient_id'];

    // Insert into Report table
    $insert_report = "INSERT INTO Report (report_id, date, diagnosis, patient_id) VALUES ('$report_id', '$date', '$diagnosis', '$patient_id')";
    if ($conn->query($insert_report) === TRUE) {
        echo "<script>alert('Report successfully added!');</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Patient Report</title>
    <link rel="stylesheet" type="text/css" href="report_style.css">
</head>
<body>
<div class="wrapper">
    <div class="sidebar">
        <h2>Navigation</h2>
        <a href="admin_home_page.php">Home</a>
        <a href="report.php">Report</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Add Patient Report</h1>
        <form method="post" action="">
            <label for="report_id">Report ID:</label>
            <input type="number" name="report_id" required min="1"><br>

            <label for="patient_id">Patient:</label>
            <select name="patient_id" required>
                <?php while($row = $patients_result->fetch_assoc()): ?>
                    <option value="<?= $row['patient_id']; ?>">
                        <?= "Patient ID: " . $row['patient_id']; ?>
                    </option>
                <?php endwhile; ?>
            </select><br>

            <label for="diagnosis">Diagnosis:</label>
            <select name="diagnosis" required>
                <option value="Normal">Normal</option>
                <option value="Abnormal">Abnormal</option>
            </select><br>

            <input type="submit" value="Add Report">
        </form>
    </div>
</div>

<div class="footer">
    &copy; 2025 Hospital Management System
</div>
</body>
</html>
