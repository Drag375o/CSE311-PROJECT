<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "hospital_management_system";
$conn = new mysqli($host, $user, $password, $db);

// Fetch employee list for dropdown
$emp_query = "SELECT employee_id, first_name, last_name FROM Employee";
$emp_result = $conn->query($emp_query);

// Pre-fill variables
$employee_id = $first_name = $middle_name = $last_name = $street_no = $street_name = $city = "";
$nid = $age = $gender = $shift = $job_type = $availability = $salary = $hospital_id = "";

function getSalaryByJobType($job_type) {
    switch (strtolower($job_type)) {
        case 'nurse': return 20000.00;
        case 'cleaner': return 12000.00;
        case 'receptionist': return 15000.00;
        case 'technician': return 22000.00;
        default: return 18000.00;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['fetch'])) {
    $employee_id = $_POST['employee_id'];
    $sql = "SELECT * FROM Employee WHERE employee_id = $employee_id";
    $result = $conn->query($sql);
    if ($row = $result->fetch_assoc()) {
        extract($row); // fills all variables with field names
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    extract($_POST);
    $availability = isset($availability) ? 1 : 0;
    $salary = getSalaryByJobType($job_type);
    $pay_date = date('Y-m-10'); // Always 10th of the current month
    $pay_status = $_POST['pay_status'];

    // Update Employee table
    $update_sql = "UPDATE Employee SET
        first_name='$first_name',
        middle_name='$middle_name',
        last_name='$last_name',
        street_no='$street_no',
        street_name='$street_name',
        city='$city',
        nid=$nid,
        age=$age,
        gender='$gender',
        shift='$shift',
        job_type='$job_type',
        availability=$availability,
        salary=$salary,
        hospital_id=$hospital_id
        WHERE employee_id=$employee_id";

    $conn->query($update_sql);

    // Update emp_salary table
    $delete_salary = "DELETE FROM emp_salary WHERE employee_id = $employee_id";
    $conn->query($delete_salary);

    $salary_id = rand(1000, 9999); // for simplicity
    $insert_salary = "INSERT INTO emp_salary (employee_id, salary_id, salary_amount, pay_date, pay_status)
                      VALUES ($employee_id, $salary_id, $salary, '$pay_date', '$pay_status')";
    $conn->query($insert_salary);

    echo "<script>alert('Employee information updated successfully.');</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Employee</title>
    <link rel="stylesheet" type="text/css" href="edit_employee_style.css">
</head>
<body>
    <div class="sidebar">
        <h2>Menu</h2>
        <a href="admin_home_page.php">Home</a>
        <a href="edit_employee.php">Edit</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Edit Employee Information</h1>

        <!-- Select Employee to Edit -->
        <form method="POST">
            <label for="employee_id">Select Employee:</label>
            <select name="employee_id" required>
                <option value="">--Select--</option>
                <?php while ($row = $emp_result->fetch_assoc()) { ?>
                    <option value="<?= $row['employee_id'] ?>" <?= ($employee_id == $row['employee_id']) ? 'selected' : '' ?>>
                        <?= $row['employee_id'] ?> - <?= $row['first_name'] ?> <?= $row['last_name'] ?>
                    </option>
                <?php } ?>
            </select>
            <button type="submit" name="fetch">Fetch</button>
        </form>

        <?php if (!empty($first_name)) { ?>
        <!-- Edit Form -->
        <form method="POST" class="edit-form">
            <input type="hidden" name="employee_id" value="<?= $employee_id ?>">

            <label>First Name:</label>
            <input type="text" name="first_name" value="<?= $first_name ?>" required pattern="[A-Za-z\s]+">

            <label>Middle Name:</label>
            <input type="text" name="middle_name" value="<?= $middle_name ?>" pattern="[A-Za-z\s]*">

            <label>Last Name:</label>
            <input type="text" name="last_name" value="<?= $last_name ?>" required pattern="[A-Za-z\s]+">

            <label>Street No:</label>
            <input type="text" name="street_no" value="<?= $street_no ?>" required pattern="[0-9]+">

            <label>Street Name:</label>
            <input type="text" name="street_name" value="<?= $street_name ?>" required pattern="[A-Za-z\s]+">

            <label>City:</label>
            <input type="text" name="city" value="<?= $city ?>" required pattern="[A-Za-z\s]+">

            <label>NID:</label>
            <input type="number" name="nid" value="<?= $nid ?>" required>

            <label>Age:</label>
            <input type="number" name="age" value="<?= $age ?>" min="18" max="50" required>

            <label>Gender:</label>
            <select name="gender" required>
                <option value="Male" <?= ($gender == "Male") ? "selected" : "" ?>>Male</option>
                <option value="Female" <?= ($gender == "Female") ? "selected" : "" ?>>Female</option>
            </select>

            <label>Shift:</label>
            <select name="shift" required>
                <option value="6am to 2pm" <?= ($shift == "6am to 2pm") ? "selected" : "" ?>>6am to 2pm</option>
                <option value="2pm to 10pm" <?= ($shift == "2pm to 10pm") ? "selected" : "" ?>>2pm to 10pm</option>
                <option value="10pm to 6am" <?= ($shift == "10pm to 6am") ? "selected" : "" ?>>10pm to 6am</option>
            </select>

            <label>Job Type:</label>
            <select name="job_type" required>
                <option value="ward-boy" <?= ($job_type == "ward-boy") ? "selected" : "" ?>>ward-boy</option>
                <option value="nurse" <?= ($job_type == "nurse") ? "selected" : "" ?>>nurse</option>
                <option value="reception-staff" <?= ($job_type == "reception-staff") ? "selected" : "" ?>>reception-staff</option>
                <option value="guard" <?= ($job_type == "guard") ? "selected" : "" ?>>guard</option>
                <option value="regular-staff" <?= ($job_type == "regular-staff") ? "selected" : "" ?>>regular-staff</option>
            </select>

            <label>Availability:</label>
            <input type="checkbox" name="availability" <?= ($availability) ? "checked" : "" ?>>

            <label>Hospital ID:</label>
            <input type="number" name="hospital_id" value="<?= $hospital_id ?>" required>

            <label>Pay Status:</label>
            <select name="pay_status" required>
                <option value="Paid">Paid</option>
                <option value="Unpaid">Unpaid</option>
            </select>

            <button type="submit" name="update">Update Employee</button>
        </form>
        <?php } ?>
    </div>

    <div class="footer">© Hospital Management System</div>
</body>
</html>
