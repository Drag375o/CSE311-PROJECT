<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hospital_management_system";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch patients
$patients_result = $conn->query("SELECT patient_id, first_name, last_name FROM patient");

// Fetch available doctors
$doctors_result = $conn->query("SELECT doctor_id, first_name, last_name, specialization, schedule FROM doctor WHERE availability = 1");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $appointment_id = $_POST['appointment_id'];
    $patient_id = $_POST['patient_id'];
    $doctor_id = $_POST['doctor_id'];
    $date = date('Y-m-d');

    // Get doctor specialization and schedule
    $doctor_query = $conn->query("SELECT specialization, schedule FROM doctor WHERE doctor_id = $doctor_id");
    $doctor_data = $doctor_query->fetch_assoc();
    $specialization = $doctor_data['specialization'];
    $schedule = $doctor_data['schedule'];

    // Assign room and bill based on specialization
    $room_map = [
        'orthopedics' => '100',
        'medicine' => '200',
        'dermatology' => '300',
        'neuroscience' => '400',
        'pediatrics' => '500',
        'cardiology' => '600'
    ];

    $bill_map = [
        'orthopedics' => '200',
        'medicine' => '500',
        'dermatology' => '300',
        'neuroscience' => '500',
        'pediatrics' => '100',
        'cardiology' => '400'
    ];

    $room = $room_map[strtolower($specialization)] ?? '000';
    $bill = $bill_map[strtolower($specialization)] ?? '0.00';

    // Insert appointment
    $sql = "INSERT INTO appointment (appointment_id, date, time, room, bill, patient_id, doctor_id) 
            VALUES ('$appointment_id', '$date', '$schedule', '$room', '$bill', '$patient_id', '$doctor_id')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Appointment added successfully!');</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Appointments</title>
    <link rel="stylesheet" type="text/css" href="appointments_patient_style.css">
</head>
<body>
<div class="wrapper">
    <div class="sidebar">
        <h2>Navigation</h2>
        <a href="admin_home_page.php">Home</a>
        <a href="appointments_patient.php">Appointments</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Add Appointment</h1>
        <form method="post" action="">
            <label for="appointment_id">Appointment ID:</label>
            <input type="number" name="appointment_id" min="1" required><br>

            <label for="patient_id">Patient:</label>
            <select name="patient_id" required>
                <?php while($row = $patients_result->fetch_assoc()): ?>
                    <option value="<?= $row['patient_id']; ?>">
                        <?= $row['first_name'] . ' ' . $row['last_name']; ?> (ID: <?= $row['patient_id']; ?>)
                    </option>
                <?php endwhile; ?>
            </select><br>

            <label for="doctor_id">Available Doctor:</label>
            <select name="doctor_id" required>
                <?php while($doc = $doctors_result->fetch_assoc()): ?>
                    <option value="<?= $doc['doctor_id']; ?>">
                        <?= $doc['first_name'] . ' ' . $doc['last_name']; ?> | <?= $doc['specialization']; ?> | Schedule: <?= $doc['schedule']; ?>
                    </option>
                <?php endwhile; ?>
            </select><br>

            <input type="submit" value="Add Appointment">
        </form>
    </div>
</div>

<div class="footer">
    &copy; 2025 Hospital Management System
</div>
</body>
</html>
