<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Home</title>
    <link rel="stylesheet" href="admin_home_page_style.css"> 
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <h2 class="sidebar-title">Options</h2>
        <ul class="nav-list">
            <li><a href="hospital_home_page.php">Hospital</a></li>
            <li><a href="service_home_page.php">Service</a></li>
            <li><a href="employee_home_page.php">Employee</a></li>
            <li><a href="doctor_home_page.php">Doctor</a></li>
            <li><a href="patient_home_page.php">Patient</a></li>
            <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
        </ul>
    </div>

    <!-- Main -->
    <div class="main-content">
        <h1 class="welcome-title">WELCOME ADMIN</h1>
        <p class="description-text">
            You are logged in as an admin. From the sidebar, you can manage hospitals, services, employees, doctors, and patients. Click "Logout" to return to the homepage.
        </p>
    </div>

    <!-- Footer -->
    <footer class="footer">
        The project is made by group 18
    </footer>
</body>
</html>
