<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Home</title>
    <link rel="stylesheet" href="employee_home_page_style.css"> 
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <h2 class="sidebar-title">Employee Operations</h2>
        <ul class="nav-list">
            <li><a href="admin_home_page.php">Home</a></li>
            <li><a href="add_employee.php">Add Employee</a></li>
            <li><a href="edit_employee.php">Edit Employee</a></li>
            <li><a href="delete_employee.php">Delete Employee</a></li>
            <li><a href="view_employee.php">View Employee</a></li>
            <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">Employee Management</h1>
        <p class="page-description">
            Welcome to the Employee Management page. Here you can add a new employee, edit existing employee details, or delete an employee. Use the options given to perform the actions.
        </p>

        <!-- Employee Operations Cards -->
        <div class="card-container">
            <div class="card">
                <h3>Add Employee</h3>
                <p>Click here to add a new employee to the system.</p>
                <a href="add_employee.php" class="card-button">Add</a>
            </div>
            <div class="card">
                <h3>Edit Employee</h3>
                <p>Click here to edit existing employee information.</p>
                <a href="edit_employee.php" class="card-button">Edit</a>
            </div>
            <div class="card">
                <h3>Delete Employee</h3>
                <p>Click here to delete an existing employee from the system.</p>
                <a href="delete_employee.php" class="card-button">Delete</a>
            </div>
            <div class="card">
                <h3>View Employee</h3>
                <p>Click here to view existing employees from the system.</p>
                <a href="view_employee.php" class="card-button">View</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        The project is made by group 18
    </footer>
</body>
</html>
