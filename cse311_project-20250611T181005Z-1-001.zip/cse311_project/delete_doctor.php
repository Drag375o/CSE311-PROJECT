<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_management_system";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$successMsg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['doctor_id'])) {
    $doctor_id = $_POST['doctor_id'];

    // Start transaction
    $conn->begin_transaction();

    try {
        // Delete from related tables first
        $conn->query("DELETE FROM Works WHERE doctor_id = $doctor_id");
        $conn->query("DELETE FROM Registrar WHERE doctor_id = $doctor_id");
        $conn->query("DELETE FROM Doc_mobile WHERE doctor_id = $doctor_id");

        // Then delete from main Doctor table
        $conn->query("DELETE FROM Doctor WHERE doctor_id = $doctor_id");

        $conn->commit();
        $successMsg = "Doctor and all related information deleted successfully.";
    } catch (Exception $e) {
        $conn->rollback();
        $successMsg = "Error deleting doctor: " . $e->getMessage();
    }
}

// Fetch all doctors for the dropdown
$result = $conn->query("SELECT doctor_id, CONCAT(first_name, ' ', middle_name, ' ', last_name) AS name FROM Doctor");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Doctor</title>
    <link rel="stylesheet" type="text/css" href="delete_doctor_style.css">
</head>
<body>

<div class="sidebar">
    <h1>HDMS</h1>
    <a href="admin_home_page.php">Home</a>
    <a href="delete_doctor.php">Delete</a>
    <a href="HOME_PAGE.php">Logout</a>
</div>

<div class="main-content">
    <h1>Delete Doctor</h1>
    <form method="post" action="delete_doctor.php">
        <label for="doctor_id">Select Doctor:</label>
        <select name="doctor_id" required>
            <option value="" disabled selected>Select a doctor</option>
            <?php
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['doctor_id'] . "'>" . $row['name'] . "</option>";
            }
            ?>
        </select>
        <br><br>
        <input type="submit" value="Delete Doctor">
    </form>
    <div class="success-msg"><?php echo $successMsg; ?></div>
</div>

<div class="footer">
    <p>&copy; 2025 Hospital Management System</p>
</div>

</body>
</html>
