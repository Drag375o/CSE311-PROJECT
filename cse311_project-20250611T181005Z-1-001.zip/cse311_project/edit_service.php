<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "hospital_management_system";
$conn = new mysqli($host, $user, $password, $db);

// Fetch all services for the dropdown
$service_query = "SELECT service_id, name FROM Service";
$service_result = $conn->query($service_query);

// Variables for the form fields
$service_id = $name = $type = $number_of_service = $availability = $hospital_id = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['fetch'])) {
    $service_id = $_POST['service_id'];
    $sql = "SELECT * FROM Service WHERE service_id = $service_id";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    $name = $row['name'];
    $type = $row['type'];
    $number_of_service = $row['number_of_service'];
    $availability = $row['availability'];
    $hospital_id = $row['hospital_id'];
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $service_id = $_POST['service_id'];
    $name = $_POST['name'];
    $type = $_POST['type'];
    $availability = isset($_POST['availability']) ? 1 : 0;
    $number_of_service = $availability ? $_POST['number_of_service'] : 0;
    $hospital_id = $_POST['hospital_id'];

    $update_sql = "UPDATE Service SET 
        name = '$name', 
        type = '$type', 
        number_of_service = $number_of_service, 
        availability = $availability, 
        hospital_id = $hospital_id 
        WHERE service_id = $service_id";

    if ($conn->query($update_sql)) {
        echo "<script>alert('Service updated successfully!');</script>";
    } else {
        echo "<script>alert('Update failed.');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Service</title>
    <link rel="stylesheet" type="text/css" href="edit_service_style.css">
</head>
<body>
    <div class="sidebar">
        <h2>Menu</h2>
        <a href="admin_home_page.php">Home</a>
        <a href="edit_service.php">Edit</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Edit Service Information</h1>

        <!-- Select Service to Edit -->
        <form method="POST">
            <label for="service_id">Select Service:</label>
            <select name="service_id" required>
                <option value="">--Select--</option>
                <?php while ($row = $service_result->fetch_assoc()) { ?>
                    <option value="<?= $row['service_id'] ?>" <?= ($service_id == $row['service_id']) ? 'selected' : '' ?>>
                        <?= $row['service_id'] ?> - <?= $row['name'] ?>
                    </option>
                <?php } ?>
            </select>
            <button type="submit" name="fetch">Fetch</button>
        </form>

        <?php if (!empty($name)) { ?>
        <!-- Edit Form -->
        <form method="POST" class="edit-form">
            <input type="hidden" name="service_id" value="<?= $service_id ?>">

            <label>Service Name:</label>
            <input type="text" name="name" value="<?= $name ?>" required pattern="[A-Za-z0-9\s]+" title="Only letters and numbers allowed.">

            <label>Type:</label>
            <select name="type" required>
                <option value="indoor" <?= ($type == "indoor") ? "selected" : "" ?>>Indoor</option>
                <option value="outdoor" <?= ($type == "outdoor") ? "selected" : "" ?>>Outdoor</option>
            </select>

            <label>Availability:</label>
            <input type="checkbox" name="availability" <?= ($availability == 1) ? "checked" : "" ?>>

            <label>Number of Services:</label>
            <input type="number" name="number_of_service" value="<?= $number_of_service ?>" min="0" <?= ($availability == 0) ? "readonly" : "" ?>>

            <label>Hospital ID:</label>
            <input type="number" name="hospital_id" value="<?= $hospital_id ?>" required>

            <button type="submit" name="update">Update Service</button>
        </form>
        <?php } ?>
    </div>

    <div class="footer">© Hospital Management System</div>

    <script>
        // Disable number_of_service if availability is unchecked
        const availabilityCheckbox = document.querySelector("input[name='availability']");
        const numberInput = document.querySelector("input[name='number_of_service']");
        if (availabilityCheckbox) {
            availabilityCheckbox.addEventListener("change", function() {
                if (this.checked) {
                    numberInput.removeAttribute("readonly");
                } else {
                    numberInput.value = 0;
                    numberInput.setAttribute("readonly", true);
                }
            });
        }
    </script>
</body>
</html>
