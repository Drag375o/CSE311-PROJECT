<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_management_system";

$conn = new mysqli($servername, $username, $password, $dbname);
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $service_id = $_POST['service_id'];
    if ($service_id < 0) {
        $message = "Service ID cannot be negative.";
    } else {
        $name = $conn->real_escape_string($_POST['name']);
        $type = $_POST['type'] === 'indoor' ? 'indoor' : 'outdoor';
        $availability = isset($_POST['availability']) ? 1 : 0;
        $number_of_service = $availability ? $_POST['number_of_service'] : 0;
        $hospital_id = $_POST['hospital_id'];

        if ($number_of_service < 0) {
            $message = "Number of Services cannot be negative.";
        } else {
            $stmt = $conn->prepare("INSERT INTO Service (service_id, name, type, number_of_service, availability, hospital_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issiii", $service_id, $name, $type, $number_of_service, $availability, $hospital_id);

            if ($stmt->execute()) {
                $message = "Service added successfully!";
            } else {
                $message = "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}

$hospital_sql = "SELECT hospital_id, hospital_name FROM Hospital";
$hospital_result = $conn->query($hospital_sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Service</title>
    <link rel="stylesheet" href="add_service_style.css">
    <script>
        function toggleNumberField() {
            const checkbox = document.getElementById('availability');
            const numberField = document.getElementById('number_of_service');
            numberField.disabled = !checkbox.checked;
            if (!checkbox.checked) numberField.value = 0;
        }
    </script>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-title">HDMS</div>
    <ul class="nav-list">
        <li><a href="admin_home_page.php">Home</a></li>
        <li><a href="hospital_home_page.php">Hospital</a></li>
        <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
    </ul>
</div>

<div class="main-content">
    <div class="page-title">Add Service</div>

    <?php if (!empty($message)): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <div class="form-container">
        <form method="post" action="">
            <label for="service_id">Service ID:</label>
            <input type="number" name="service_id" required min="0">

            <label for="name">Service Name:</label>
            <input type="text" name="name" required pattern="[A-Za-z0-9\s]+" title="Only letters, numbers, and spaces are allowed">

            <label for="type">Type of Service:</label>
            <select name="type" required>
                <option value="indoor">Indoor</option>
                <option value="outdoor">Outdoor</option>
            </select>

            <label for="availability">Available:</label>
            <input type="checkbox" name="availability" id="availability" onchange="toggleNumberField()">

            <label for="number_of_service">Number of Services:</label>
            <input type="number" name="number_of_service" id="number_of_service" value="0" min="0" required>

            <label for="hospital_id">Hospital:</label>
            <select name="hospital_id" required>
                <option value="">Select Hospital</option>
                <?php
                while ($row = $hospital_result->fetch_assoc()) {
                    echo "<option value='" . $row['hospital_id'] . "'>" . $row['hospital_name'] . "</option>";
                }
                ?>
            </select>

            <div class="button-container">
                <input type="submit" value="Add Service">
            </div>
        </form>
    </div>
</div>

<div class="footer">Hospital Digital Management System</div>
</body>
</html>
