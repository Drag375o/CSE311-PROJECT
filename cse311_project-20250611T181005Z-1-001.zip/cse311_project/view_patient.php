<?php
// Connect to database
$conn = new mysqli("localhost", "root", "", "hospital_management_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to get all patient information and related data
$sql = "
SELECT 
    p.patient_id AS ID,
    p.nid AS NID,
    CONCAT(p.first_name, ' ', p.middle_name, ' ', p.last_name) AS NAME,
    CONCAT(p.street_no, ' ', p.street_name, ', ', p.city) AS LOCATION,
    p.date_of_birth AS DOB,
    p.gender AS GENDER,
    pm.mobile AS CONTACT,
    pmh.medical_history AS `Medical History`,
    r.report_id AS RID,
    r.diagnosis AS Diagnosis,
    l.lab_test_id AS LID,
    l.test_name AS `LAB Test`,
    lph.hospital_id AS `HOSPITAL ID`,
    a.appointment_id AS `Appointment ID`,
    a.time AS `A.Time`,
    a.room AS `ROOM NO`,
    a.bill AS BILL,
    a.doctor_id AS `Assigned Doctor ID`,
    CASE WHEN ep.stable IS NOT NULL THEN 
        CASE WHEN ep.stable = 1 THEN 'Stable' ELSE 'Unstable' END 
        ELSE '' 
    END AS `Emergency Patient`,
    rp.update_info AS `Regular Patient`
FROM Patient p
LEFT JOIN Pat_Mobile pm ON p.patient_id = pm.patient_id
LEFT JOIN Pat_Medical_History pmh ON p.patient_id = pmh.patient_id
LEFT JOIN emergency_patient ep ON p.patient_id = ep.patient_id
LEFT JOIN regular_patient rp ON p.patient_id = rp.patient_id
LEFT JOIN Report r ON p.patient_id = r.patient_id
LEFT JOIN lab_patient_hospital lph ON p.patient_id = lph.patient_id
LEFT JOIN lab_test l ON lph.lab_test_id = l.lab_test_id
LEFT JOIN Appointment a ON p.patient_id = a.patient_id
ORDER BY p.patient_id;
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Patient</title>
    <link rel="stylesheet" href="view_patient_style.css">
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-title">Menu</div>
        <ul class="nav-list">
            <li><a href="admin_home_page.php">Home</a></li>
            <li><a href="view_patient.php">View Patients</a></li>
            <li><a class="logout" href="HOME_PAGE.php">Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <h1 class="page-title">Patient Records</h1>
        <div class="table-container">
            <table>
                <tr>
                    <th>ID</th>
                    <th>NID</th>
                    <th>NAME</th>
                    <th>LOCATION</th>
                    <th>DOB</th>
                    <th>GENDER</th>
                    <th>CONTACT</th>
                    <th>Medical History</th>
                    <th>RID</th>
                    <th>Diagnosis</th>
                    <th>LID</th>
                    <th>LAB Test</th>
                    <th>HOSPITAL ID</th>
                    <th>Appointment ID</th>
                    <th>A.Time</th>
                    <th>ROOM NO</th>
                    <th>BILL</th>
                    <th>Assigned Doctor ID</th>
                    <th>Emergency Patient</th>
                    <th>Regular Patient</th>
                </tr>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        foreach ($row as $value) {
                            echo "<td>" . htmlspecialchars($value) . "</td>";
                        }
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='20'>No patient records found.</td></tr>";
                }
                ?>
            </table>
        </div>
    </div>

    <div class="footer">Hospital Data Management System ©</div>
</body>
</html>
