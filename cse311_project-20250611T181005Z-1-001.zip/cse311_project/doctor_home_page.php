<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Doctor Home</title>
    <link rel="stylesheet" href="doctor_home_page_style.css"> <!-- Link to external CSS -->
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <h2 class="sidebar-title">Doctor Operations</h2>
        <ul class="nav-list">
            <li><a href="admin_home_page.php">Home</a></li>
            <li><a href="add_doctor.php">Add Doctor</a></li>
            <li><a href="edit_doctor.php">Edit Doctor</a></li>
            <li><a href="delete_doctor.php">Delete Doctor</a></li>
            <li><a href="view_doctor.php">View Doctor</a></li>
            <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">Doctor Management</h1>
        <p class="page-description">
            Welcome to the Doctor Management page. Here you can add a new doctor, edit existing doctor details, or delete a doctor. Use the options given to perform the actions.
        </p>

        <!-- Doctor Operations Cards -->
        <div class="card-container">
            <div class="card">
                <h3>Add Doctor</h3>
                <p>Click here to add a new doctor to the system.</p>
                <a href="add_doctor.php" class="card-button">Add</a>
            </div>
            <div class="card">
                <h3>Edit Doctor</h3>
                <p>Click here to edit existing doctor information.</p>
                <a href="edit_doctor.php" class="card-button">Edit</a>
            </div>
            <div class="card">
                <h3>Delete Doctor</h3>
                <p>Click here to delete an existing doctor from the system.</p>
                <a href="delete_doctor.php" class="card-button">Delete</a>
            </div>
            <div class="card">
                <h3>View Doctor</h3>
                <p>Click here to view existing doctors from the system.</p>
                <a href="view_doctor.php" class="card-button">View</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        The project is made by group 18
    </footer>
</body>
</html>
