<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_management_system";

$conn = new mysqli($servername, $username, $password, $dbname);
$message = "";

// Fetch hospitals for dropdown
$hospitalOptions = "";
$result = $conn->query("SELECT hospital_id, hospital_name FROM Hospital");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $hospitalOptions .= "<option value='" . $row['hospital_id'] . "'>" . $row['hospital_name'] . " (ID: " . $row['hospital_id'] . ")</option>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $doctor_id = (int)$_POST['doctor_id'];
    $nid = (int)$_POST['nid'];
    $age = (int)$_POST['age'];
    $years_of_exp = (int)$_POST['years_of_exp'];
    $hospital_id = (int)$_POST['hospital_id'];

    if ($doctor_id <= 0) {
        $message = "Doctor ID must be greater than 0.";
    } elseif ($age < 20 || $age > 80) {
        $message = "Age must be between 20 and 80.";
    } elseif ($years_of_exp < 0 || $years_of_exp > $age - 20) {
        $message = "Years of Experience must be between 0 and (Age - 20).";
    } elseif (empty($_POST['mobile1'])) {
        $message = "At least one mobile number is required.";
    } else {
        $first_name = $conn->real_escape_string($_POST['first_name']);
        $middle_name = $conn->real_escape_string($_POST['middle_name']);
        $last_name = $conn->real_escape_string($_POST['last_name']);
        $street_no = $conn->real_escape_string($_POST['street_no']);
        $street_name = $conn->real_escape_string($_POST['street_name']);
        $city = $conn->real_escape_string($_POST['city']);
        $gender = $_POST['gender'];
        $schedule = $_POST['schedule'];
        $specialization = $_POST['specialization'];
        $availability = isset($_POST['availability']) ? 1 : 0;

        $stmt = $conn->prepare("INSERT INTO Doctor (doctor_id, first_name, middle_name, last_name, street_no, street_name, city, nid, age, gender, schedule, specialization, availability, years_of_exp)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssssiisssii", $doctor_id, $first_name, $middle_name, $last_name, $street_no, $street_name, $city, $nid, $age, $gender, $schedule, $specialization, $availability, $years_of_exp);
        
        if ($stmt->execute()) {
            $mobiles = [];
            for ($i = 1; $i <= 3; $i++) {
                if (!empty($_POST["mobile$i"])) {
                    $mobile = $conn->real_escape_string($_POST["mobile$i"]);
                    if (strlen($mobile) != 11 || !ctype_digit($mobile)) {
                        $message = "Each mobile number must be 11 digits.";
                        break;
                    }
                    $mobiles[] = $mobile;
                }
            }

            if (empty($message)) {
                foreach ($mobiles as $mob) {
                    $stmt2 = $conn->prepare("INSERT INTO Doc_mobile (doctor_id, mobile) VALUES (?, ?)");
                    $stmt2->bind_param("is", $doctor_id, $mob);
                    $stmt2->execute();
                }

                // Insert into Works table
                $stmtWorks = $conn->prepare("INSERT INTO Works (doctor_id, hospital_id) VALUES (?, ?)");
                $stmtWorks->bind_param("ii", $doctor_id, $hospital_id);
                $stmtWorks->execute();
                $stmtWorks->close();

                // Check if doctor is also a registrar
                if (isset($_POST['is_registrar'])) {
                    $result = $conn->query("SELECT MAX(reg_id) AS max_reg_id FROM Registrar");
                    $row = $result->fetch_assoc();
                    $next_reg_id = $row['max_reg_id'] + 1;
                    if ($next_reg_id === null) {
                        $next_reg_id = 1;
                    }

                    $stmt3 = $conn->prepare("INSERT INTO Registrar (doctor_id, reg_id) VALUES (?, ?)");
                    $stmt3->bind_param("ii", $doctor_id, $next_reg_id);

                    if ($stmt3->execute()) {
                        $message = "Doctor added successfully, assigned to hospital, and assigned as Registrar (ID: $next_reg_id)!";
                    } else {
                        $message = "Doctor added and assigned to hospital, but failed to assign Registrar role. Error: " . $stmt3->error;
                    }

                    $stmt3->close();
                } else {
                    $message = "Doctor added successfully and assigned to hospital!";
                }
            }
        } else {
            $message = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Doctor</title>
    <link rel="stylesheet" href="add_doctor_style.css">
</head>
<body>

<div class="sidebar">
    <div class="sidebar-title">HDMS</div>
    <ul class="nav-list">
        <li><a href="admin_home_page.php">Home</a></li>
        <li><a href="add_doctor.php">Add</a></li>
        <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
    </ul>
</div>

<div class="main-content">
    <div class="page-title">Add Doctor</div>

    <?php if (!empty($message)): ?>
        <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>

    <div class="form-container">
        <form method="post" action="">
            <label for="doctor_id">Doctor ID:</label>
            <input type="number" name="doctor_id" required min="1">

            <label for="first_name">First Name:</label>
            <input type="text" name="first_name" required pattern="[A-Za-z\s]+" title="Only letters allowed">

            <label for="middle_name">Middle Name:</label>
            <input type="text" name="middle_name" pattern="[A-Za-z\s]*" title="Only letters allowed">

            <label for="last_name">Last Name:</label>
            <input type="text" name="last_name" required pattern="[A-Za-z\s]+" title="Only letters allowed">

            <label for="street_no">Street No:</label>
            <input type="text" name="street_no" pattern="[0-9]{1,9}" title="Up to 9 digits" required>

            <label for="street_name">Street Name:</label>
            <input type="text" name="street_name" required pattern="[A-Za-z\s]+" title="Only letters allowed">

            <label for="city">City:</label>
            <input type="text" name="city" required pattern="[A-Za-z\s]+" title="Only letters allowed">

            <label for="nid">NID:</label>
            <input type="number" name="nid" required>

            <label for="age">Age:</label>
            <input type="number" name="age" min="20" max="80" required>

            <label for="years_of_exp">Years of Experience:</label>
            <input type="number" name="years_of_exp" min="0" required>

            <label for="gender">Gender:</label>
            <select name="gender" required>
                <option value="">Select</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select>

            <label for="schedule">Schedule:</label>
            <select name="schedule" required>
                <option value="">Select Schedule</option>
                <option value="6am to 2pm">6am to 2pm</option>
                <option value="2pm to 10pm">2pm to 10pm</option>
                <option value="10pm to 6am">10pm to 6am</option>
            </select>

            <label for="specialization">Specialization:</label>
            <select name="specialization" required>
                <option value="">Select</option>
                <option value="orthopedics">Orthopedics</option>
                <option value="medicine">Medicine</option>
                <option value="dematology">Dermatology</option>
                <option value="neuroscience">Neuroscience</option>
                <option value="pediatrics">Pediatrics</option>
                <option value="cardiology">Cardiology</option>
            </select>

            <label for="availability">Available:</label>
            <input type="checkbox" name="availability">

            <label for="hospital_id">Assign to Hospital:</label>
            <select name="hospital_id" required>
                <option value="">Select Hospital</option>
                <?php echo $hospitalOptions; ?>
            </select>

            <label for="is_registrar">Registrar:</label>
            <input type="checkbox" name="is_registrar" id="is_registrar">
            <label>Mobile Numbers:</label>
            
            <input type="text" name="mobile1" required pattern="\d{11}" title="Must be 11 digits">
            <input type="text" name="mobile2" pattern="\d{11}" title="Must be 11 digits">
            <input type="text" name="mobile3" pattern="\d{11}" title="Must be 11 digits">

            

            <input type="submit" value="Add Doctor">
        </form>
    </div>
</div>

<div class="footer">Hospital Digital Management System</div>
</body>
</html>
