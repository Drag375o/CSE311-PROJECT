<?php
session_start();

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$database = "hospital_management_system"; // change this to your actual database name

$conn = new mysqli($servername, $username, $password, $database);
// Connection check
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST["id"]);
    $admin_name = $_POST["admin_name"];
    $admin_password = $_POST["password"];

    $sql = "SELECT * FROM admin_loggin WHERE admin_id = $id AND admin_name = '$admin_name' AND password = '$admin_password'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows == 1) {
        header("Location: admin_home_page.php");
        exit();
    } else {
        $error = "Invalid ID, Name, or Password. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link rel="stylesheet" href="admin_login_style.css"> 
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar azure-navbar">
        <h1 class="nav-heading">HOSPITAL MANAGEMENT SYSTEM</h1>
        <div class="nav-links">
            <a href="admin_login.php">ADMIN Login</a>
            <a href="HOME_PAGE.php">About</a>
        </div>
    </nav>

    <!-- Login Form Section -->
    <section class="admin-login-section">
        <h2 class="login-title">ADMIN LOGIN</h2>

        <?php if (!empty($error)): ?>
            <p style="color: red; font-weight: bold;"><?php echo $error; ?></p>
        <?php endif; ?>

        <form action="admin_login.php" method="POST" class="login-form">
            <label for="id">Admin ID:</label>
            <input type="text" id="id" name="id" required><br><br>

            <label for="admin_name">Admin Name:</label>
            <input type="text" id="admin_name" name="admin_name" required><br><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br><br>

            <input type="submit" value="Login">
        </form>
    </section>

    <!-- Footer -->
    <footer class="footer">
        The project is made by group 18
    </footer>
</body>
</html>
