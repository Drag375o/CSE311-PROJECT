<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hospital Home</title>
    <link rel="stylesheet" href="hospital_home_page_style.css"> 
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <h2 class="sidebar-title">Hospital Operations</h2>
        <ul class="nav-list">
            <li><a href="admin_home_page.php">Home</a></li>
            <li><a href="add_hospital.php">Add Hospital</a></li>
            <li><a href="edit_hospital.php">Edit Hospital</a></li>
            <li><a href="delete_hospital.php">Delete Hospital</a></li>
            <li><a href="view_hospital.php">View Hospital</a></li>
            <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">Hospital Management</h1>
        <p class="page-description">
            Welcome to the Hospital Management page. Here you can add a new hospital, edit hospital details, or delete an existing hospital. Use the options in the sidebar to perform the actions.
        </p>

        <!-- Hospital Operations Cards -->
        <div class="card-container">
            <div class="card">
                <h3>Add Hospital</h3>
                <p>Click here to add a new hospital to the system.</p>
                <a href="add_hospital.php" class="card-button">Add</a>
            </div>
            <div class="card">
                <h3>Edit Hospital</h3>
                <p>Click here to edit existing hospital information.</p>
                <a href="edit_hospital.php" class="card-button">Edit</a>
            </div>
            <div class="card">
                <h3>Delete Hospital</h3>
                <p>Click here to delete an existing hospital from the system.</p>
                <a href="delete_hospital.php" class="card-button">Delete</a>
            </div>
            <div class="card">
                <h3>View Hospital</h3>
                <p>Click here to view existing hospitals from the system.</p>
                <a href="View_hospital.php" class="card-button">View</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        The project is made by group 18
    </footer>
</body>
</html>
