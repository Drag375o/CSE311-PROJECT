-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 12, 2025 at 01:07 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_loggin`
--

CREATE TABLE `admin_loggin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_loggin`
--

INSERT INTO `admin_loggin` (`admin_id`, `admin_name`, `password`) VALUES
(1, 'Atahar', '123456'),
(2, 'Shawlin', '654321');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appointment_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `time` varchar(30) DEFAULT NULL,
  `room` varchar(10) DEFAULT NULL,
  `bill` decimal(10,2) DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appointment_id`, `date`, `time`, `room`, `bill`, `patient_id`, `doctor_id`) VALUES
(234, '2025-04-11', '6am to 2pm', '200', 500.00, 2323, 123),
(343, '2025-04-12', '2pm to 10pm', '000', 0.00, 6789, 23),
(25555, '2025-04-12', '2pm to 10pm', '200', 500.00, 6789, 345),
(34555, '2025-04-12', '10pm to 6am', '100', 200.00, 6789, 12);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `doctor_id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `street_no` varchar(10) DEFAULT NULL,
  `street_name` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `nid` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `schedule` varchar(50) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `availability` tinyint(1) DEFAULT NULL,
  `years_of_exp` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`doctor_id`, `first_name`, `middle_name`, `last_name`, `street_no`, `street_name`, `city`, `nid`, `age`, `gender`, `schedule`, `specialization`, `availability`, `years_of_exp`) VALUES
(12, 'Mahi', 'mohim', 'ALvi', '12367', 'nilkahntopur', 'Dhaka', 2147483647, 23, 'Male', '10pm to 6am', 'orthopedics', 1, 2),
(23, 'Atahar', 'insan', 'sakib', '121', 'nilkahn', 'Dhaka', 2147483647, 24, 'Male', '2pm to 10pm', 'dematology', 1, 2),
(123, 'Atahar', 'Hossain', 'Piash', '123', 'Dirha', 'Dhaka', 2147483647, 21, 'Male', '6am to 2pm', 'medicine', 1, 1),
(343, 'Fahmid', 'mohim', 'ahmed', '21', 'Gadhapul', 'Noakhali', 1230976234, 21, 'Male', '6am to 2pm', 'Orthopedic', 1, 2),
(345, 'Hafi', 'insan', 'rafi', '232', 'asad', 'Dhaka', 2147483647, 24, 'Male', '2pm to 10pm', 'medicine', 1, 4),
(45454, 'Tanvir', 'Hossain', 'ahmed', '343', 'Bashvobon', 'Basrishal', 2147483647, 28, 'Male', '2pm to 10pm', 'dematology', 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `doc_mobile`
--

CREATE TABLE `doc_mobile` (
  `doctor_id` int(11) NOT NULL,
  `mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doc_mobile`
--

INSERT INTO `doc_mobile` (`doctor_id`, `mobile`) VALUES
(12, '01234567777'),
(12, '04234244234'),
(23, '01234563333'),
(23, '03232323322'),
(123, '01234567891'),
(345, '01234567891'),
(345, '03232323333'),
(45454, '01234567999');

-- --------------------------------------------------------

--
-- Table structure for table `emergency_patient`
--

CREATE TABLE `emergency_patient` (
  `patient_id` int(11) NOT NULL,
  `stable` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `emergency_patient`
--

INSERT INTO `emergency_patient` (`patient_id`, `stable`) VALUES
(2323, 0),
(32332, 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `street_no` varchar(10) DEFAULT NULL,
  `street_name` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `nid` int(11) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `shift` varchar(20) DEFAULT NULL,
  `job_type` varchar(50) DEFAULT NULL,
  `availability` tinyint(1) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `hospital_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `first_name`, `middle_name`, `last_name`, `street_no`, `street_name`, `city`, `nid`, `age`, `gender`, `shift`, `job_type`, `availability`, `salary`, `hospital_id`) VALUES
(8789, 'Mahi', 'Hossain', 'Preo', '656', 'Nilkahndoman', 'Dhaka', 2147483647, 32, 'Male', '2pm to 10pm', 'ward-boy', 1, 20000.00, 2),
(45454, 'Amin', 'Hossain', 'AKash', '7878', 'Horidashpur', 'Noakhali', 2147483647, 23, 'Male', '10pm to 6am', 'reception-staff', 1, 18000.00, 4),
(244778, 'Fahim', 'Mahmud', 'Siam', '4546', 'Hararam', 'Dhaka', 2147483647, 27, 'Male', '2pm to 10pm', 'guard', 1, 20000.00, 3);

-- --------------------------------------------------------

--
-- Table structure for table `emp_salary`
--

CREATE TABLE `emp_salary` (
  `employee_id` int(11) NOT NULL,
  `salary_id` int(11) NOT NULL,
  `salary_amount` decimal(10,2) DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `pay_status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `emp_salary`
--

INSERT INTO `emp_salary` (`employee_id`, `salary_id`, `salary_amount`, `pay_date`, `pay_status`) VALUES
(8789, 4194, 20000.00, '0000-00-00', 'Unpaid'),
(45454, 9573, 18000.00, '2025-04-10', 'Paid'),
(244778, 7701, 20000.00, '2025-04-10', 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hospital_id` int(11) NOT NULL,
  `hospital_name` varchar(100) DEFAULT NULL,
  `street_no` varchar(10) DEFAULT NULL,
  `street_name` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hospital_id`, `hospital_name`, `street_no`, `street_name`, `city`) VALUES
(2, 'adaamnagar', '322', 'nilkahn', 'Basrishal'),
(3, 'Agasarahum', '239', 'Matiarai', 'Basrishal'),
(4, 'Pitasha', '3333333333', 'Nilkunjo', 'Dhaka');

-- --------------------------------------------------------

--
-- Table structure for table `hospital_mobile`
--

CREATE TABLE `hospital_mobile` (
  `hospital_id` int(11) NOT NULL,
  `mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hospital_mobile`
--

INSERT INTO `hospital_mobile` (`hospital_id`, `mobile`) VALUES
(2, '34535435335'),
(3, '00998776876'),
(4, '99912313331');

-- --------------------------------------------------------

--
-- Table structure for table `lab_patient_hospital`
--

CREATE TABLE `lab_patient_hospital` (
  `hospital_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `lab_test_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lab_patient_hospital`
--

INSERT INTO `lab_patient_hospital` (`hospital_id`, `patient_id`, `lab_test_id`) VALUES
(2, 32332, 2312),
(3, 129000, 232676);

-- --------------------------------------------------------

--
-- Table structure for table `lab_test`
--

CREATE TABLE `lab_test` (
  `lab_test_id` int(11) NOT NULL,
  `test_name` varchar(100) DEFAULT NULL,
  `result` text DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lab_test`
--

INSERT INTO `lab_test` (`lab_test_id`, `test_name`, `result`, `date`) VALUES
(2311, 'MRI', 'Normal', '2025-04-11'),
(2312, 'CMP', NULL, '2025-04-11'),
(232676, 'X-ray', NULL, '2025-04-12');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `street_no` varchar(10) DEFAULT NULL,
  `street_name` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `nid` int(11) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`patient_id`, `first_name`, `middle_name`, `last_name`, `street_no`, `street_name`, `city`, `nid`, `date_of_birth`, `gender`) VALUES
(2323, 'Sadman', 'NULL', 'sakib', '23', 'asad', 'Dhaka', 2147483647, '2001-02-01', 'Male'),
(6789, 'Tanvir', 'mohim', 'rafi', '4544', 'akramnagar', 'Noakhali', 908235614, '2005-06-05', 'Male'),
(32332, 'Syed', 'mohim', 'Preo', '232', 'nilkahn', 'Basrishal', 2147483647, '2000-01-01', 'Male'),
(129000, 'Sadiya', 'piyali', 'Preya', '123432', 'Asaaadgate', 'Dhaka', 2147483647, '2001-04-01', 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `pat_medical_history`
--

CREATE TABLE `pat_medical_history` (
  `patient_id` int(11) NOT NULL,
  `medical_history` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pat_medical_history`
--

INSERT INTO `pat_medical_history` (`patient_id`, `medical_history`) VALUES
(2323, 'Influyenza'),
(2323, 'Typhoid'),
(129000, 'Corona'),
(129000, 'Typhoid');

-- --------------------------------------------------------

--
-- Table structure for table `pat_mobile`
--

CREATE TABLE `pat_mobile` (
  `patient_id` int(11) NOT NULL,
  `mobile` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pat_mobile`
--

INSERT INTO `pat_mobile` (`patient_id`, `mobile`) VALUES
(2323, '01234567444'),
(32332, '01234567888'),
(129000, '01234567222'),
(129000, '03222223333'),
(129000, '03242323333');

-- --------------------------------------------------------

--
-- Table structure for table `registrar`
--

CREATE TABLE `registrar` (
  `doctor_id` int(11) NOT NULL,
  `reg_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registrar`
--

INSERT INTO `registrar` (`doctor_id`, `reg_id`) VALUES
(345, 1),
(23, 3);

-- --------------------------------------------------------

--
-- Table structure for table `regular_patient`
--

CREATE TABLE `regular_patient` (
  `patient_id` int(11) NOT NULL,
  `update_info` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `regular_patient`
--

INSERT INTO `regular_patient` (`patient_id`, `update_info`) VALUES
(129000, 'sick');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `report_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `patient_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`report_id`, `date`, `diagnosis`, `patient_id`) VALUES
(254, '2025-04-12', 'Abnormal', 129000),
(344, '2025-04-11', 'Abnormal', 32332),
(1222222, '2025-04-12', 'Abnormal', 129000);

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `service_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `number_of_service` int(11) DEFAULT NULL,
  `availability` tinyint(1) DEFAULT NULL,
  `hospital_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`service_id`, `name`, `type`, `number_of_service`, `availability`, `hospital_id`) VALUES
(231, 'room', 'indoor', 402, 1, 2),
(232, 'Ambulance', 'outdoor', 3, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `works`
--

CREATE TABLE `works` (
  `hospital_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `works`
--

INSERT INTO `works` (`hospital_id`, `doctor_id`) VALUES
(2, 45454),
(3, 12),
(3, 23),
(3, 123);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_loggin`
--
ALTER TABLE `admin_loggin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `doc_mobile`
--
ALTER TABLE `doc_mobile`
  ADD PRIMARY KEY (`doctor_id`,`mobile`);

--
-- Indexes for table `emergency_patient`
--
ALTER TABLE `emergency_patient`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`),
  ADD KEY `hospital_id` (`hospital_id`);

--
-- Indexes for table `emp_salary`
--
ALTER TABLE `emp_salary`
  ADD PRIMARY KEY (`employee_id`,`salary_id`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`hospital_id`);

--
-- Indexes for table `hospital_mobile`
--
ALTER TABLE `hospital_mobile`
  ADD PRIMARY KEY (`hospital_id`,`mobile`);

--
-- Indexes for table `lab_patient_hospital`
--
ALTER TABLE `lab_patient_hospital`
  ADD PRIMARY KEY (`hospital_id`,`patient_id`,`lab_test_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `lab_test_id` (`lab_test_id`);

--
-- Indexes for table `lab_test`
--
ALTER TABLE `lab_test`
  ADD PRIMARY KEY (`lab_test_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `pat_medical_history`
--
ALTER TABLE `pat_medical_history`
  ADD PRIMARY KEY (`patient_id`,`medical_history`);

--
-- Indexes for table `pat_mobile`
--
ALTER TABLE `pat_mobile`
  ADD PRIMARY KEY (`patient_id`,`mobile`);

--
-- Indexes for table `registrar`
--
ALTER TABLE `registrar`
  ADD PRIMARY KEY (`doctor_id`),
  ADD UNIQUE KEY `reg_id` (`reg_id`);

--
-- Indexes for table `regular_patient`
--
ALTER TABLE `regular_patient`
  ADD PRIMARY KEY (`patient_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `patient_id` (`patient_id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`service_id`),
  ADD KEY `hospital_id` (`hospital_id`);

--
-- Indexes for table `works`
--
ALTER TABLE `works`
  ADD PRIMARY KEY (`hospital_id`,`doctor_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  ADD CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`);

--
-- Constraints for table `doc_mobile`
--
ALTER TABLE `doc_mobile`
  ADD CONSTRAINT `doc_mobile_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`);

--
-- Constraints for table `emergency_patient`
--
ALTER TABLE `emergency_patient`
  ADD CONSTRAINT `emergency_patient_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`);

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`hospital_id`);

--
-- Constraints for table `emp_salary`
--
ALTER TABLE `emp_salary`
  ADD CONSTRAINT `emp_salary_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`);

--
-- Constraints for table `hospital_mobile`
--
ALTER TABLE `hospital_mobile`
  ADD CONSTRAINT `hospital_mobile_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`hospital_id`);

--
-- Constraints for table `lab_patient_hospital`
--
ALTER TABLE `lab_patient_hospital`
  ADD CONSTRAINT `lab_patient_hospital_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`hospital_id`),
  ADD CONSTRAINT `lab_patient_hospital_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`),
  ADD CONSTRAINT `lab_patient_hospital_ibfk_3` FOREIGN KEY (`lab_test_id`) REFERENCES `lab_test` (`lab_test_id`);

--
-- Constraints for table `pat_medical_history`
--
ALTER TABLE `pat_medical_history`
  ADD CONSTRAINT `pat_medical_history_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`);

--
-- Constraints for table `pat_mobile`
--
ALTER TABLE `pat_mobile`
  ADD CONSTRAINT `pat_mobile_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`);

--
-- Constraints for table `registrar`
--
ALTER TABLE `registrar`
  ADD CONSTRAINT `registrar_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`);

--
-- Constraints for table `regular_patient`
--
ALTER TABLE `regular_patient`
  ADD CONSTRAINT `regular_patient_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`);

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `report_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`);

--
-- Constraints for table `service`
--
ALTER TABLE `service`
  ADD CONSTRAINT `service_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`hospital_id`);

--
-- Constraints for table `works`
--
ALTER TABLE `works`
  ADD CONSTRAINT `works_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospital` (`hospital_id`),
  ADD CONSTRAINT `works_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctor` (`doctor_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
