<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Fetch hospital IDs
$hospital_query = "SELECT hospital_id, hospital_name FROM hospital";
$hospital_result = $conn->query($hospital_query);

// Insert logic
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employee_id = $_POST["employee_id"];
    $first_name = $_POST["first_name"];
    $middle_name = $_POST["middle_name"];
    $last_name = $_POST["last_name"];
    $street_no = $_POST["street_no"];
    $street_name = $_POST["street_name"];
    $city = $_POST["city"];
    $nid = $_POST["nid"];
    $age = $_POST["age"];
    $gender = $_POST["gender"];
    $shift = $_POST["shift"];
    $job_type = $_POST["job_type"];
    $availability = isset($_POST["availability"]) ? 1 : 0;
    $hospital_id = $_POST["hospital_id"];
    $salary = 0;

    // Determine salary
    switch ($job_type) {
        case "ward-boy": $salary = 20000; break;
        case "nurse": $salary = 40000; break;
        case "reception-staff": $salary = 30000; break;
        case "guard": $salary = 20000; break;
        case "regular-staff": $salary = 20000; break;
    }

    // Insert into Employee
    $stmt = $conn->prepare("INSERT INTO Employee (employee_id, first_name, middle_name, last_name, street_no, street_name, city, nid, age, gender, shift, job_type, availability, salary, hospital_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssssiisssidi", $employee_id, $first_name, $middle_name, $last_name, $street_no, $street_name, $city, $nid, $age, $gender, $shift, $job_type, $availability, $salary, $hospital_id);

    if ($stmt->execute()) {
        // Insert into emp_salary
        $salary_id = rand(1000, 9999); // you can use a better ID logic
        $pay_date = date("Y-m-10");
        $pay_status = isset($_POST["pay_status"]) ? "Paid" : "Unpaid";

        $salary_stmt = $conn->prepare("INSERT INTO emp_salary (employee_id, salary_id, salary_amount, pay_date, pay_status) VALUES (?, ?, ?, ?, ?)");
        $salary_stmt->bind_param("iisds", $employee_id, $salary_id, $salary, $pay_date, $pay_status);
        $salary_stmt->execute();

        $message = "Employee added successfully!";
    } else {
        $message = "Error: " . $stmt->error;
    }

    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Employee</title>
    <link rel="stylesheet" type="text/css" href="add_employee_style.css">
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-title">Employee</div>
        <ul class="nav-list">
            <li><a href="admin_home_page.php">Home</a></li>
            <li><a href="add_employee.php">Add</a></li>
            <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <h1 class="page-title">Add Employee</h1>

        <?php if (!empty($message)) echo "<div class='message'>$message</div>"; ?>

        <div class="form-container">
            <form method="POST">
                <label>Employee ID:</label>
                <input type="number" name="employee_id" min="1" required>

                <label>First Name:</label>
                <input type="text" name="first_name" pattern="[A-Za-z]+" required>

                <label>Middle Name:</label>
                <input type="text" name="middle_name" pattern="[A-Za-z]*">

                <label>Last Name:</label>
                <input type="text" name="last_name" pattern="[A-Za-z]+" required>

                <label>Street No:</label>
                <input type="text" name="street_no" pattern="[0-9]{1,9}" required>

                <label>Street Name:</label>
                <input type="text" name="street_name" pattern="[A-Za-z ]+" required>

                <label>City:</label>
                <input type="text" name="city" pattern="[A-Za-z ]+" required>

                <label>NID:</label>
                <input type="number" name="nid" required>

                <label>Age:</label>
                <input type="number" name="age" min="18" max="50" required>

                <label>Gender:</label>
                <select name="gender" required>
                    <option value="">Select</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Other</option>
                </select>

                <label>Shift:</label>
                <select name="shift" required>
                    <option value="">Select</option>
                    <option>6am to 2pm</option>
                    <option>2pm to 10pm</option>
                    <option>10pm to 6am</option>
                </select>

                <label>Job Type:</label>
                <select name="job_type" required>
                    <option value="">Select</option>
                    <option>ward-boy</option>
                    <option>nurse</option>
                    <option>reception-staff</option>
                    <option>guard</option>
                    <option>regular-staff</option>
                </select>

                <label><input type="checkbox" name="availability"> Available</label>
                <label><input type="checkbox" name="pay_status"> Pay Status (Paid)</label>

                <label>Hospital:</label>
                <select name="hospital_id" required>
                    <option value="">Select Hospital</option>
                    <?php while($row = $hospital_result->fetch_assoc()): ?>
                        <option value="<?= $row['hospital_id'] ?>"><?= $row['hospital_id'] ?> - <?= $row['hospital_name'] ?></option>
                    <?php endwhile; ?>
                </select>

                <div style="text-align: center;">
                    <input type="submit" value="Add Employee">
                </div>
            </form>
        </div>
    </div>

    <div class="footer">Hospital Database Management System</div>
</body>
</html>
