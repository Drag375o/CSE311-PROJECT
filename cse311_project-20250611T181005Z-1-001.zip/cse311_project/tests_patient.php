<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hospital_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch patients
$patients_result = $conn->query("SELECT patient_id, first_name, last_name FROM patient");

// Fetch hospitals (fixed field name to hospital_name)
$hospitals_result = $conn->query("SELECT hospital_id, hospital_name FROM hospital");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lab_test_id = $_POST['lab_test_id'];
    $test_name = $_POST['test_name'];
    $date = date('Y-m-d');
    $patient_id = $_POST['patient_id'];
    $hospital_id = $_POST['hospital_id'];

    // Insert into lab_test table
    $insert_lab_test = "INSERT INTO lab_test (lab_test_id, test_name, date) VALUES ('$lab_test_id', '$test_name', '$date')";
    $conn->query($insert_lab_test);

    // Insert into lab_patient_hospital
    $insert_relation = "INSERT INTO lab_patient_hospital (hospital_id, patient_id, lab_test_id) VALUES ('$hospital_id', '$patient_id', '$lab_test_id')";
    $conn->query($insert_relation);

    echo "<script>alert('Lab Test successfully added!');</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Patient Lab Tests</title>
    <link rel="stylesheet" type="text/css" href="tests_patient_style.css">
</head>
<body>
<div class="wrapper">
    <div class="sidebar">
        <h2>Navigation</h2>
        <a href="admin_home_page.php">Home</a>
        <a href="tests_patient.php">Lab Test</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Add Lab Test</h1>
        <form method="post" action="">
            <label for="lab_test_id">Lab Test ID:</label>
            <input type="number" name="lab_test_id" required min="1"><br>

            <label for="test_name">Test Name:</label>
            <select name="test_name" required>
                <option value="X-ray">X-ray</option>
                <option value="Ultrasound">Ultrasound</option>
                <option value="MRI">MRI</option>
                <option value="Bloodtest">Bloodtest</option>
                <option value="CMP">CMP</option>
            </select><br>

            <label for="patient_id">Patient:</label>
            <select name="patient_id" required>
                <?php while($row = $patients_result->fetch_assoc()): ?>
                    <option value="<?= $row['patient_id']; ?>">
                        <?= $row['first_name'] . ' ' . $row['last_name']; ?> (ID: <?= $row['patient_id']; ?>)
                    </option>
                <?php endwhile; ?>
            </select><br>

            <label for="hospital_id">Hospital:</label>
            <select name="hospital_id" required>
                <?php while($row = $hospitals_result->fetch_assoc()): ?>
                    <option value="<?= $row['hospital_id']; ?>">
                        <?= $row['hospital_name']; ?> (ID: <?= $row['hospital_id']; ?>)
                    </option>
                <?php endwhile; ?>
            </select><br>

            <input type="submit" value="Add Lab Test">
        </form>
    </div>
</div>

<div class="footer">
    &copy; 2025 Hospital Management System
</div>

</body>
</html>
