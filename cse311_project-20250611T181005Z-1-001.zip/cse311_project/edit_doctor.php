<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "hospital_management_system";
$conn = new mysqli($host, $user, $password, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$selectedDoctor = null;
$doctorData = null;
$mobiles = [];

if (isset($_POST['select_doctor'])) {
    $selectedDoctor = $_POST['doctor_id'];

    // Fetch doctor data
    $sql = "SELECT * FROM Doctor WHERE doctor_id = $selectedDoctor";
    $result = $conn->query($sql);
    $doctorData = $result->fetch_assoc();

    // Fetch mobiles
    $mobResult = $conn->query("SELECT mobile FROM Doc_mobile WHERE doctor_id = $selectedDoctor");
    while ($row = $mobResult->fetch_assoc()) {
        $mobiles[] = $row['mobile'];
    }

    // Check registrar
    $isRegistrar = $conn->query("SELECT * FROM Registrar WHERE doctor_id = $selectedDoctor")->num_rows > 0;
}

if (isset($_POST['update_doctor'])) {
    $doctor_id = $_POST['doctor_id'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $street_no = $_POST['street_no'];
    $street_name = $_POST['street_name'];
    $city = $_POST['city'];
    $nid = $_POST['nid'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $schedule = $_POST['schedule'];
    $specialization = $_POST['specialization'];
    $availability = isset($_POST['availability']) ? 1 : 0;
    $years_of_exp = $_POST['years_of_exp'];
    $mobiles = array_filter($_POST['mobiles'], fn($m) => !empty(trim($m)));
    $isRegistrar = isset($_POST['is_registrar']);

    // Update doctor
    $conn->query("UPDATE Doctor SET first_name='$first_name', middle_name='$middle_name', last_name='$last_name',
        street_no='$street_no', street_name='$street_name', city='$city', nid=$nid, age=$age,
        gender='$gender', schedule='$schedule', specialization='$specialization',
        availability=$availability, years_of_exp=$years_of_exp WHERE doctor_id=$doctor_id");

    // Update mobiles
    $conn->query("DELETE FROM Doc_mobile WHERE doctor_id = $doctor_id");
    foreach ($mobiles as $mobile) {
        $conn->query("INSERT INTO Doc_mobile (doctor_id, mobile) VALUES ($doctor_id, '$mobile')");
    }

    // Update registrar
    $conn->query("DELETE FROM Registrar WHERE doctor_id = $doctor_id");
    if ($isRegistrar) {
        $reg_id = rand(1000, 9999); // Random reg ID
        $conn->query("INSERT INTO Registrar (doctor_id, reg_id) VALUES ($doctor_id, $reg_id)");
    }

    echo "<script>alert('Doctor updated successfully!');</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Doctor</title>
    <link rel="stylesheet" href="edit_doctor_style.css">
</head>
<body>
<div class="sidebar">
    <h2>Doctor Panel</h2>
    <a href="admin_home_page.php">Home</a>
    <a href="edit_doctor.php">Edit Doctor</a>
    <a href="HOME_PAGE.php">Logout</a>
</div>

<div class="main-content">
    <h1>Edit Doctor</h1>

    <form method="POST">
        <label>Select Doctor:</label>
        <select name="doctor_id" required>
            <option value="">-- Select Doctor --</option>
            <?php
            $res = $conn->query("SELECT doctor_id, first_name, last_name FROM Doctor");
            while ($row = $res->fetch_assoc()) {
                $selected = ($selectedDoctor == $row['doctor_id']) ? "selected" : "";
                echo "<option value='{$row['doctor_id']}' $selected>Dr. {$row['first_name']} {$row['last_name']} (ID: {$row['doctor_id']})</option>";
            }
            ?>
        </select>
        <button type="submit" name="select_doctor">Load Doctor</button>
    </form>

    <?php if ($doctorData): ?>
    <form method="POST">
        <input type="hidden" name="doctor_id" value="<?= $doctorData['doctor_id'] ?>">

        <label>First Name:</label>
        <input type="text" name="first_name" value="<?= $doctorData['first_name'] ?>" pattern="[A-Za-z]+" required>

        <label>Middle Name:</label>
        <input type="text" name="middle_name" value="<?= $doctorData['middle_name'] ?>" pattern="[A-Za-z]*">

        <label>Last Name:</label>
        <input type="text" name="last_name" value="<?= $doctorData['last_name'] ?>" pattern="[A-Za-z]+" required>

        <label>Street No:</label>
        <input type="text" name="street_no" value="<?= $doctorData['street_no'] ?>" pattern="[0-9]{0,9}" required>

        <label>Street Name:</label>
        <input type="text" name="street_name" value="<?= $doctorData['street_name'] ?>" pattern="[A-Za-z ]+" required>

        <label>City:</label>
        <input type="text" name="city" value="<?= $doctorData['city'] ?>" pattern="[A-Za-z ]+" required>

        <label>NID:</label>
        <input type="number" name="nid" value="<?= $doctorData['nid'] ?>" required>

        <label>Age:</label>
        <input type="number" name="age" value="<?= $doctorData['age'] ?>" min="20" max="80" required>

        <label>Years of Experience:</label>
        <input type="number" name="years_of_exp" value="<?= $doctorData['years_of_exp'] ?>" min="0" max="<?= $doctorData['age'] - 20 ?>" required>

        <label>Gender:</label>
        <select name="gender" required>
            <option <?= $doctorData['gender'] == 'Male' ? 'selected' : '' ?>>Male</option>
            <option <?= $doctorData['gender'] == 'Female' ? 'selected' : '' ?>>Female</option>
        </select>

        <label>Schedule:</label>
        <select name="schedule" required>
            <option <?= $doctorData['schedule'] == '6am to 2pm' ? 'selected' : '' ?>>6am to 2pm</option>
            <option <?= $doctorData['schedule'] == '2pm to 10pm' ? 'selected' : '' ?>>2pm to 10pm</option>
            <option <?= $doctorData['schedule'] == '10pm to 6am' ? 'selected' : '' ?>>10pm to 6am</option>
        </select>

        <label>Specialization:</label>
        <select name="specialization" required>
            <?php
            $specs = ['orthopedics','medicine','dematology','neuroscience','pediatrics','cardiology'];
            foreach ($specs as $spec) {
                $selected = $doctorData['specialization'] == $spec ? "selected" : "";
                echo "<option $selected>$spec</option>";
            }
            ?>
        </select>

        <label>Availability:</label>
        <input type="checkbox" name="availability" <?= $doctorData['availability'] ? 'checked' : '' ?>>

        <label>Mobile Numbers (1-3):</label>
        <?php for ($i = 0; $i < 3; $i++): ?>
            <input type="text" name="mobiles[]" value="<?= $mobiles[$i] ?? '' ?>" pattern="[0-9]{11}" <?= $i == 0 ? 'required' : '' ?>>
        <?php endfor; ?>

        <label>Is Registrar:</label>
        <input type="checkbox" name="is_registrar" <?= $isRegistrar ? 'checked' : '' ?>>

        <br><br>
        <button type="submit" name="update_doctor">Update Doctor</button>
    </form>
    <?php endif; ?>
</div>

</body>
</html>
