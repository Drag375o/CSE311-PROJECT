<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_management_system";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$successMsg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['employee_id'])) {
    $employee_id = $_POST['employee_id'];

    // Start transaction
    $conn->begin_transaction();

    try {
        // Delete from related table first
        $conn->query("DELETE FROM emp_salary WHERE employee_id = $employee_id");

        // Then delete from main Employee table
        $conn->query("DELETE FROM Employee WHERE employee_id = $employee_id");

        $conn->commit();
        $successMsg = "Employee and all related information deleted successfully.";
    } catch (Exception $e) {
        $conn->rollback();
        $successMsg = "Error deleting employee: " . $e->getMessage();
    }
}

// Fetch all employees for the dropdown
$result = $conn->query("SELECT employee_id, CONCAT(first_name, ' ', middle_name, ' ', last_name) AS name FROM Employee");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Employee</title>
    <link rel="stylesheet" type="text/css" href="delete_employee_style.css">
</head>
<body>

<div class="sidebar">
    <h1>HDMS</h1>
    <a href="admin_home_page.php">Home</a>
    <a href="delete_employee.php">Delete</a>
    <a href="HOME_PAGE.php">Logout</a>
</div>

<div class="main-content">
    <h1>Delete Employee</h1>
    <form method="post" action="delete_employee.php">
        <label for="employee_id">Select Employee:</label>
        <select name="employee_id" required>
            <option value="" disabled selected>Select an employee</option>
            <?php
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['employee_id'] . "'>" . $row['name'] . "</option>";
            }
            ?>
        </select>
        <br><br>
        <input type="submit" value="Delete Employee">
    </form>
    <div class="success-msg"><?php echo $successMsg; ?></div>
</div>

<div class="footer">
    <p>&copy; 2025 Hospital Management System</p>
</div>

</body>
</html>
