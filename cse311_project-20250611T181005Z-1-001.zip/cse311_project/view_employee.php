<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hospital_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch employee joined with salary info
$sql = "SELECT e.employee_id, e.nid, CONCAT(e.first_name, ' ', e.middle_name, ' ', e.last_name) AS name,
               CONCAT(e.street_no, ' ', e.street_name, ' ', e.city) AS location,
               e.age, e.gender, e.shift, e.job_type, e.availability, e.salary,
               e.hospital_id, s.salary_id, s.pay_date, s.pay_status
        FROM Employee e
        LEFT JOIN emp_salary s ON e.employee_id = s.employee_id
        ORDER BY e.employee_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Employees</title>
    <link rel="stylesheet" type="text/css" href="view_employee_style.css">
</head>
<body>
<div class="wrapper">
    <div class="sidebar">
        <h2>Navigation</h2>
        <a href="admin_home_page.php">Home</a>
        <a href="view_employee.php">View</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Employee Information</h1>
        <div class="employee-container">
            <?php
            if ($result->num_rows > 0) {
                echo "<table>
                        <tr>
                            <th>ID</th>
                            <th>NID</th>
                            <th>Name</th>
                            <th>Location</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>Work Shift</th>
                            <th>Job</th>
                            <th>Salary ID</th>
                            <th>Salary</th>
                            <th>Hospital ID</th>
                            <th>Available</th>
                            <th>Pay Day</th>
                            <th>Paid</th>
                        </tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['employee_id']}</td>
                            <td>{$row['nid']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['location']}</td>
                            <td>{$row['age']}</td>
                            <td>{$row['gender']}</td>
                            <td>{$row['shift']}</td>
                            <td>{$row['job_type']}</td>
                            <td>" . ($row['salary_id'] ?? '-') . "</td>
                            <td>{$row['salary']}</td>
                            <td>{$row['hospital_id']}</td>
                            <td>" . ($row['availability'] ? 'YES' : 'NO') . "</td>
                            <td>" . ($row['pay_date'] ?? '-') . "</td>
                            <td>" . ($row['pay_status'] ?? '-') . "</td>
                          </tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No employee data found.</p>";
            }
            ?>
        </div>
    </div>
</div>

<div class="footer">
    &copy; 2025 Hospital Management System
</div>
</body>
</html>
