<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hospital_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all service data
$sql = "SELECT * FROM Service ORDER BY service_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Services</title>
    <link rel="stylesheet" type="text/css" href="view_service_style.css">
</head>
<body>
<div class="wrapper">
    <div class="sidebar">
        <h2>Navigation</h2>
        <a href="admin_home_page.php">Home</a>
        <a href="view_service.php">View</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Service Information</h1>
        <div class="service-container">
            <?php
            if ($result->num_rows > 0) {
                echo "<table>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Available</th>
                            <th>Hospital ID</th>
                        </tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $row['service_id'] . "</td>
                            <td>" . $row['name'] . "</td>
                            <td>" . $row['type'] . "</td>
                            <td>" . $row['number_of_service'] . "</td>
                            <td>" . ($row['availability'] ? 'YES' : 'NO') . "</td>
                            <td>" . $row['hospital_id'] . "</td>
                          </tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No service data found.</p>";
            }
            ?>
        </div>
    </div>
</div>

<div class="footer">
    &copy; 2025 Hospital Management System
</div>
</body>
</html>
