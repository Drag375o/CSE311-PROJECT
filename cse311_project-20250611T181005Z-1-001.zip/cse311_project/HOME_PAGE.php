<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hospital Management System</title>
    <link rel="stylesheet" href="HOME_PAGE_STYLE.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <h1 class="nav-heading">HOSPITAL MANAGEMENT SYSTEM</h1>
        <div class="nav-links">
            <a href="admin_login.php">ADMIN Login</a>
            <a href="HOME_PAGE.php">About</a>
        </div>
    </nav>

    <!-- About Section -->
    <section class="about-section">
        <h2 class="welcome-text">WELCOME</h2>
        <p class="description-text">
            This Hospital Management System is designed to manage hospital activities efficiently. 
            It includes features to manage patient information, doctor records, appointments, lab reports, 
            and hospital staff, all integrated into one system for ease of access and management.
        </p>
    </section>

    <!-- Footer -->
    <footer class="footer">
        The project is made by group 18
    </footer>
</body>
</html>
