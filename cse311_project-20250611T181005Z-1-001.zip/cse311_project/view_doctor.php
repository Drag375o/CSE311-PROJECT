<?php
$conn = new mysqli("localhost", "root", "", "hospital_management_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to join all necessary tables and fetch doctor data
$sql = "SELECT d.doctor_id, d.first_name, d.middle_name, d.last_name, d.nid, d.age, d.gender,
               d.schedule, d.specialization, d.years_of_exp, d.availability,
               CONCAT(d.street_no, ' ', d.street_name, ' ', d.city) AS location,
               dm.mobile, w.hospital_id, r.reg_id
        FROM Doctor d
        LEFT JOIN Doc_mobile dm ON d.doctor_id = dm.doctor_id
        LEFT JOIN Works w ON d.doctor_id = w.doctor_id
        LEFT JOIN Registrar r ON d.doctor_id = r.doctor_id
        ORDER BY d.doctor_id";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Doctors</title>
    <link rel="stylesheet" type="text/css" href="view_doctor_style.css">
</head>
<body>
    <div class="sidebar">
        <a href="admin_home_page.php">Home</a>
        <a href="view_employee.php">View Employee</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Doctor Records</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>NID</th>
                <th>Name</th>
                <th>Location</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Schedule</th>
                <th>Specialization</th>
                <th>Years of Exp</th>
                <th>Available</th>
                <th>Hospital ID</th>
                <th>Contact</th>
                <th>Registrar</th>
                <th>Registrar ID</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $full_name = $row['first_name'] . " " . $row['middle_name'] . " " . $row['last_name'];
                    $available = $row['availability'] ? "YES" : "NO";
                    $is_registrar = $row['reg_id'] ? "YES" : "NO";
                    echo "<tr>
                            <td>{$row['doctor_id']}</td>
                            <td>{$row['nid']}</td>
                            <td>$full_name</td>
                            <td>{$row['location']}</td>
                            <td>{$row['age']}</td>
                            <td>{$row['gender']}</td>
                            <td>{$row['schedule']}</td>
                            <td>{$row['specialization']}</td>
                            <td>{$row['years_of_exp']}</td>
                            <td>$available</td>
                            <td>{$row['hospital_id']}</td>
                            <td>{$row['mobile']}</td>
                            <td>$is_registrar</td>
                            <td>{$row['reg_id']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='14'>No doctor records found.</td></tr>";
            }
            $conn->close();
            ?>
        </table>
    </div>
</body>
</html>
