<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "hospital_management_system";

$conn = new mysqli($host, $user, $password, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all patients for dropdown
$patients = $conn->query("SELECT patient_id, first_name, last_name FROM Patient");

// When patient is selected
$selected_patient = null;
if (isset($_POST['select_patient'])) {
    $selected_id = $_POST['selected_patient_id'];
    $selected_patient = $conn->query("SELECT * FROM Patient WHERE patient_id = $selected_id")->fetch_assoc();

    // Get existing mobile numbers
    $mobiles = $conn->query("SELECT mobile FROM Pat_Mobile WHERE patient_id = $selected_id")->fetch_all(MYSQLI_ASSOC);

    // Get medical history
    $history = $conn->query("SELECT medical_history FROM Pat_Medical_History WHERE patient_id = $selected_id")->fetch_all(MYSQLI_ASSOC);

    // Emergency and regular patient
    $emergency = $conn->query("SELECT stable FROM emergency_patient WHERE patient_id = $selected_id");
    $regular = $conn->query("SELECT update_info FROM regular_patient WHERE patient_id = $selected_id");

    $is_emergency = $emergency->num_rows > 0;
    $stable_status = $is_emergency ? $emergency->fetch_assoc()['stable'] : null;
    $update_info = !$is_emergency ? $regular->fetch_assoc()['update_info'] : null;
}

// Update patient info
if (isset($_POST['update_patient'])) {
    $id = $_POST['patient_id'];
    $first = $_POST['first_name'];
    $middle = $_POST['middle_name'];
    $last = $_POST['last_name'];
    $street_no = $_POST['street_no'];
    $street_name = $_POST['street_name'];
    $city = $_POST['city'];
    $nid = $_POST['nid'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $mobiles = array_filter([$_POST['mobile1'], $_POST['mobile2'], $_POST['mobile3']]);
    $history = explode(",", $_POST['medical_history']); // comma-separated input

    // Update patient table
    $conn->query("UPDATE Patient SET 
        first_name='$first', middle_name='$middle', last_name='$last', 
        street_no='$street_no', street_name='$street_name', city='$city',
        nid=$nid, date_of_birth='$dob', gender='$gender'
        WHERE patient_id=$id");

    // Update mobiles: delete existing and insert new
    $conn->query("DELETE FROM Pat_Mobile WHERE patient_id=$id");
    foreach ($mobiles as $m) {
        $conn->query("INSERT INTO Pat_Mobile VALUES ($id, '$m')");
    }

    // Update medical history
    $conn->query("DELETE FROM Pat_Medical_History WHERE patient_id=$id");
    foreach ($history as $h) {
        $conn->query("INSERT INTO Pat_Medical_History VALUES ($id, '" . trim($h) . "')");
    }

    // Handle emergency/regular
    $conn->query("DELETE FROM emergency_patient WHERE patient_id=$id");
    $conn->query("DELETE FROM regular_patient WHERE patient_id=$id");

    if (isset($_POST['is_emergency'])) {
        $stable = $_POST['stable'] === "stable" ? 1 : 0;
        $conn->query("INSERT INTO emergency_patient VALUES ($id, $stable)");
    } else {
        $update = $_POST['update_info'];
        $conn->query("INSERT INTO regular_patient VALUES ($id, '$update')");
    }

    echo "<script>alert('Patient info updated successfully');</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Patient</title>
    <link rel="stylesheet" type="text/css" href="edit_patient_style.css">
</head>
<body>
    <div class="sidebar">
        <a href="admin_home_page.php">Home</a>
        <a href="edit_patient.php">Edit Patient</a>
        <a href="HOME_PAGE.php">Logout</a>
    </div>

    <div class="main-content">
        <h2>Edit Patient Information</h2>

        <form method="POST" class="center-form">
            <label>Select Patient:</label>
            <select name="selected_patient_id" required>
                <option value="">-- Select --</option>
                <?php while ($row = $patients->fetch_assoc()) { ?>
                    <option value="<?= $row['patient_id'] ?>" <?= isset($selected_patient) && $row['patient_id'] == $selected_patient['patient_id'] ? 'selected' : '' ?>>
                        <?= $row['patient_id'] . " - " . $row['first_name'] . " " . $row['last_name'] ?>
                    </option>
                <?php } ?>
            </select>
            <button type="submit" name="select_patient">Load Patient</button>
        </form>

        <?php if ($selected_patient) { ?>
        <form method="POST" class="center-form">
            <input type="hidden" name="patient_id" value="<?= $selected_patient['patient_id'] ?>">

            <label>First Name:</label>
            <input type="text" name="first_name" value="<?= $selected_patient['first_name'] ?>" required pattern="[A-Za-z]+" >

            <label>Middle Name:</label>
            <input type="text" name="middle_name" value="<?= $selected_patient['middle_name'] ?>" pattern="[A-Za-z]*">

            <label>Last Name:</label>
            <input type="text" name="last_name" value="<?= $selected_patient['last_name'] ?>" required pattern="[A-Za-z]+" >

            <label>Street No:</label>
            <input type="text" name="street_no" value="<?= $selected_patient['street_no'] ?>" required pattern="[0-9]{1,10}">

            <label>Street Name:</label>
            <input type="text" name="street_name" value="<?= $selected_patient['street_name'] ?>" required pattern="[A-Za-z ]+">

            <label>City:</label>
            <input type="text" name="city" value="<?= $selected_patient['city'] ?>" required pattern="[A-Za-z ]+">

            <label>NID:</label>
            <input type="number" name="nid" value="<?= $selected_patient['nid'] ?>" required>

            <label>Date of Birth:</label>
            <input type="date" name="dob" value="<?= $selected_patient['date_of_birth'] ?>" required>

            <label>Gender:</label>
            <select name="gender" required>
                <option value="Male" <?= $selected_patient['gender'] == "Male" ? 'selected' : '' ?>>Male</option>
                <option value="Female" <?= $selected_patient['gender'] == "Female" ? 'selected' : '' ?>>Female</option>
                <option value="Other" <?= $selected_patient['gender'] == "Other" ? 'selected' : '' ?>>Other</option>
            </select>

            <label>Mobile 1:</label>
            <input type="text" name="mobile1" value="<?= $mobiles[0]['mobile'] ?? '' ?>" required pattern="[0-9]{11}">
            <label>Mobile 2:</label>
            <input type="text" name="mobile2" value="<?= $mobiles[1]['mobile'] ?? '' ?>" pattern="[0-9]{11}">
            <label>Mobile 3:</label>
            <input type="text" name="mobile3" value="<?= $mobiles[2]['mobile'] ?? '' ?>" pattern="[0-9]{11}">

            <label>Medical History (comma separated):</label>
            <input type="text" name="medical_history" value="<?= implode(', ', array_column($history, 'medical_history')) ?>">

            <label><input type="checkbox" name="is_emergency" <?= $is_emergency ? 'checked' : '' ?>> Emergency Patient</label>

            <?php if ($is_emergency) { ?>
                <label>Stable Status:</label>
                <select name="stable">
                    <option value="stable" <?= $stable_status ? 'selected' : '' ?>>Stable</option>
                    <option value="unstable" <?= !$stable_status ? 'selected' : '' ?>>Unstable</option>
                </select>
            <?php } else { ?>
                <label>Health Status:</label>
                <select name="update_info">
                    <option value="sick" <?= $update_info == 'sick' ? 'selected' : '' ?>>Sick</option>
                    <option value="well" <?= $update_info == 'well' ? 'selected' : '' ?>>Well</option>
                </select>
            <?php } ?>

            <button type="submit" name="update_patient">Update Patient</button>
        </form>
        <?php } ?>
    </div>

    <div class="footer">
        <p>Hospital Database Management System</p>
    </div>
</body>
</html>
