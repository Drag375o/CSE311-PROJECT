<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Patient Home</title>
    <link rel="stylesheet" href="patient_home_page_style.css"> <!-- Link to external CSS -->
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <h2 class="sidebar-title">Patient Operations</h2>
        <ul class="nav-list">
            <li><a href="admin_home_page.php">Home</a></li>
            <li><a href="add_patient.php">Add Patient</a></li>
            <li><a href="edit_patient.php">Edit Patient</a></li>
            <li><a href="delete_patient.php">Delete Patient</a></li>
            <li><a href="view_patient.php">View Patient</a></li>
            <li><a href="tests_patient.php">Take Test</a></li>
            <li><a href="appointments_patient.php">Make Appointment</a></li>
            <li><a href="report.php">Report</a></li>
            <li><a href="HOME_PAGE.php" class="logout">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">Patient Management</h1>
        <p class="page-description">
            Welcome to the Patient Management page. Here you can add a new patient, edit existing patient details, delete a patient, take tests, and schedule appointments. Use the options given to perform the actions.
        </p>

        <!-- Patient Operations Cards -->
        <div class="card-container">
            <div class="card">
                <h3>Add Patient</h3>
                <p>Click here to add a new patient to the system.</p>
                <a href="add_patient.php" class="card-button">Add</a>
            </div>
            <div class="card">
                <h3>Edit Patient</h3>
                <p>Click here to edit existing patient information.</p>
                <a href="edit_patient.php" class="card-button">Edit</a>
            </div>
            <div class="card">
                <h3>Delete Patient</h3>
                <p>Click here to delete an existing patient from the system.</p>
                <a href="delete_patient.php" class="card-button">Delete</a>
            </div>
            <div class="card">
                <h3>Take Test</h3>
                <p>Click here to take a medical test.</p>
                <a href="tests_patient.php" class="card-button">Test</a>
            </div>
            <div class="card">
                <h3>Make Appointment</h3>
                <p>Click here to make a appointment.</p>
                <a href="appointments_patient.php" class="card-button">Appointment</a>
            </div>
            <div class="card">
                <h3>Report</h3>
                <p>Click here to operate on an existing patients report.</p>
                <a href="report.php" class="card-button">Report</a>
            </div>
            <div class="card">
                <h3>View Patient</h3>
                <p>Click here to view existing patients from the system.</p>
                <a href="view_patient.php" class="card-button">View</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        The project is made by group 18
    </footer>
</body>
</html>
