<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital_management_system";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$successMsg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['hospital_id'])) {
    $hospital_id = $_POST['hospital_id'];

    // Start transaction
    $conn->begin_transaction();

    try {
        // Delete related entries from lab_patient_hospital
        $conn->query("DELETE FROM lab_patient_hospital WHERE hospital_id = $hospital_id");

        // Delete from Service
        $conn->query("DELETE FROM Service WHERE hospital_id = $hospital_id");

        // Delete from Works
        $conn->query("DELETE FROM Works WHERE hospital_id = $hospital_id");

        // Get employees for salary deletion
        $emp_result = $conn->query("SELECT employee_id FROM Employee WHERE hospital_id = $hospital_id");
        while ($emp_row = $emp_result->fetch_assoc()) {
            $eid = $emp_row['employee_id'];
            $conn->query("DELETE FROM emp_salary WHERE employee_id = $eid");
        }

        // Delete Employees
        $conn->query("DELETE FROM Employee WHERE hospital_id = $hospital_id");

        // Get patients for cascade deletions
        $pat_result = $conn->query("SELECT patient_id FROM lab_patient_hospital WHERE hospital_id = $hospital_id");
        $patient_ids = [];
        while ($row = $pat_result->fetch_assoc()) {
            $patient_ids[] = $row['patient_id'];
        }

        foreach ($patient_ids as $pid) {
            $conn->query("DELETE FROM Pat_Mobile WHERE patient_id = $pid");
            $conn->query("DELETE FROM Pat_Medical_History WHERE patient_id = $pid");
            $conn->query("DELETE FROM emergency_patient WHERE patient_id = $pid");
            $conn->query("DELETE FROM regular_patient WHERE patient_id = $pid");
            $conn->query("DELETE FROM Report WHERE patient_id = $pid");
            $conn->query("DELETE FROM Appointment WHERE patient_id = $pid");
            $conn->query("DELETE FROM Patient WHERE patient_id = $pid");
        }

        // Delete from Hospital_Mobile
        $conn->query("DELETE FROM Hospital_Mobile WHERE hospital_id = $hospital_id");

        // Finally, delete from Hospital
        $conn->query("DELETE FROM Hospital WHERE hospital_id = $hospital_id");

        $conn->commit();
        $successMsg = "Hospital and all related records successfully deleted.";
    } catch (Exception $e) {
        $conn->rollback();
        $successMsg = "Error: " . $e->getMessage();
    }
}

// Fetch all hospitals for the dropdown
$result = $conn->query("SELECT hospital_id, hospital_name FROM Hospital");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Hospital</title>
    <link rel="stylesheet" type="text/css" href="delete_hospital_style.css">
</head>
<body>

<div class="sidebar">
    <h1>HDMS</h1>
    <a href="admin_home_page.php">Home</a>
    <a href="delete_hospital.php">Delete</a>
    <a href="HOME_PAGE.php">Logout</a>
</div>

<div class="main-content">
    <h1>Delete Hospital</h1>
    <form method="post" action="delete_hospital.php">
        <label for="hospital_id">Select Hospital:</label>
        <select name="hospital_id" required>
            <option value="" disabled selected>Select a hospital</option>
            <?php
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['hospital_id'] . "'>ID: " . $row['hospital_id'] . " | " . $row['hospital_name'] . "</option>";
            }
            ?>
        </select>
        <br><br>
        <input type="submit" value="Delete Hospital">
    </form>
    <div class="success-msg"><?php echo $successMsg; ?></div>
</div>

<div class="footer">
    <p>&copy; 2025 Hospital Management System</p>
</div>

</body>
</html>
